/* global angular */
/* global Highcharts */
/* global L */
/* jshint loopfunc: true */
/* global $ */
/* global document */

(function () {
    'use strict';
    angular.module('lcio.tw')
    .directive('lcioMap', function () {
        return {
            scope: {
                chartOptions: '=chartOptions',
                fromModal: '@',
                profileLat: '@profileLat',
                profileLon: '@profileLon'
            },
            controller: ['$scope', '$element', '$attrs', '$log',
                function ($scope, $element, $attrs, $log) {

                    var map;
                    var markerGroup = null;
                    var centeredOnHome = false;

                    this.redraw = function () {
                        $log.debug('lcioMap directive redraw called');

                        if (!map) {

                            L.mapbox.accessToken = 'pk.eyJ1IjoicnRwZGV2b3BzIiwiYSI6ImNpZjVlbGxycDAybWVzYWt0Y3RxNWp6NTcifQ.5L87J-P0UJymWDuJGIw53Q';

                            if ($scope.fromModal === 'true') {
                                map = L.mapbox.map('mapModal', 'mapbox.light');
                            } else {
                                map = L.mapbox.map('map', 'mapbox.light');
                            }
                            map.setView([39.8282, -98.5795], 4);
                        }

                        if (markerGroup === null) {
                            markerGroup = L.layerGroup();
                        } else {
                            markerGroup.clearLayers();
                        }
                        var pointAttrs;
                        var colorMap = {
                            'point_high': {
                                icon: L.Icon.Default.extend({
                                    options: {
                                        iconUrl: '/images/map-pin-red.png',
                                        shadowSize: [0, 0]
                                    }
                                }), color: 'red'
                            },
                            'point_medium': {
                                icon: L.Icon.Default.extend({
                                    options: {
                                        iconUrl: '/images/map-pin-yellow.png',
                                        shadowSize: [0, 0]
                                    }
                                }), color: 'yellow'
                            },
                            'point_low': {
                                icon: L.Icon.Default.extend({
                                    options: {
                                        iconUrl: '/images/map-pin-green.png',
                                        shadowSize: [0, 0]
                                    }
                                }), color: 'green'
                            },
                            'point_noscore': {
                                icon: L.Icon.Default.extend({
                                    options: {
                                        iconUrl: '/images/map-pin-blue.png',
                                        shadowSize: [0, 0]
                                    }
                                }), color: '#7AA3B7'
                            },
                            'point_home': {
                                circle: {
                                    radius: 7,
                                    color: '#0000FF',
                                    opacity: 0.7,
                                    fill: true,
                                    fillColor: '#0000FF',
                                    fillOpacity: 0.10
                                }
                            },
                            'point_unknown': {
                                icon: L.Icon.Default.extend({
                                    options: {
                                        iconUrl: '/images/map-pin-gray.png',
                                        shadowSize: [0, 0]
                                    }
                                }), color: 'gray'
                            }
                        };

                        if (!!$scope.chartOptions['series_data']['points']) {
                            for (var j in $scope.chartOptions['series_data']['points']) {

                                if ($scope.chartOptions['series_data']['points'].hasOwnProperty(j)) {

                                    var remotePoint = $scope.chartOptions['series_data']['points'][j];

                                    pointAttrs = colorMap['point_unknown'];
                                    if ('type' in remotePoint) {
                                        if (remotePoint['type'] in colorMap) {
                                            // $log.debug('point for ' + remotePoint.name + ' is ' + remotePoint.type + '');
                                            pointAttrs = colorMap[remotePoint.type];
                                        }
                                    }
                                    var remoteMarker;
                                    if ('icon' in pointAttrs) {
                                        remoteMarker = new L.marker([remotePoint.lat, remotePoint.lon], {icon: new pointAttrs.icon()});
                                        remoteMarker.popUpColor = pointAttrs.color;
                                    } else if ('circle' in pointAttrs) {
                                        remoteMarker = new L.circleMarker([remotePoint.lat, remotePoint.lon], pointAttrs.circle);
                                    } else {
                                        $log.error('map marker should be one of icon or circle');
                                        return;
                                    }

                                    // js:hint "quotmark": false
                                    var popupText = 'Location: ' + remotePoint.name + ', ' + remotePoint.code + ': (' + remotePoint.lat + ', ' + remotePoint.lon + ')<br/>' +
                                        'DNS: ' + remotePoint.host + '<br/>' +
                                        'Threat: ' + remotePoint.score + ' <a href=http://www.senderbase.org/lookup/?search_string=' + remotePoint.addr + '\ntarget=_blank>Details</a><br/>' +
                                        'Bytes: ' + remotePoint.z;
                                    var htmlText = '<div class="lc-custom-marker">' +
                                        '<div class="lc-custom-marker-header">' + remotePoint.addr + '<button class="btn btn-link pull-right lc-custom-marker-header-close">&times;</button></div>' +
                                        '<div class="lc-custom-marker-content">' + popupText + '</div>' +
                                        '</div>';
                                    var customPopUp = L.popup({'closeButton': false}).setContent(htmlText);
                                    remoteMarker.bindPopup(customPopUp);

                                    remoteMarker.on('mouseover', function (e) {
                                        this.openPopup();
                                        $('.lc-custom-marker-header').attr('style', 'background-color:' + this.popUpColor);
                                    });

                                    $(document).on('click', '.lc-custom-marker-header', function () {
                                        this.closePopup();
                                    }.bind(remoteMarker));

                                    markerGroup.addLayer(remoteMarker);
                                }
                            }
                        }

                        // RED LINES BETWEEN HOME AND IP

                        if ($scope.profileLat && $scope.profileLon) {

                            var homeLatLng = new L.latLng([$scope.profileLat, $scope.profileLon]);

                            // When we first figure out our home lat/lon, re-center the map
                            // (no need to reset zoom level here).
                            if (!centeredOnHome) {
                                map.setView(homeLatLng, map.getZoom());
                                centeredOnHome = true;
                            }

                            // draw a marker at the home
                            pointAttrs = colorMap['point_home'];
                            var homeMarker;
                            if ('icon' in pointAttrs) {
                                homeMarker = new L.marker(homeLatLng, {icon: new pointAttrs.icon()});
                            } else if ('circle' in pointAttrs) {
                                homeMarker = new L.circleMarker(homeLatLng, pointAttrs.circle);
                            } else {
                                $log.error('map marker should be one of icon or circle');
                                return;
                            }
                            markerGroup.addLayer(homeMarker);

                            // add mouseover to the home circle
                            (function (point) {
                                homeMarker.on('mouseover', function (e) {
                                    this.bindPopup('Home' + ': (' + parseFloat($scope.profileLat).toFixed(4) + ', ' + parseFloat($scope.profileLon).toFixed(4) + ')').openPopup();
                                });
                            })(homeLatLng);

                            var homePoint = new L.latLng($scope.profileLat, $scope.profileLon);

                            // pick a line style
                            var lineConfig = {
                                color: 'red',
                                weight: 2,
                                opacity: 0.15,
                                smoothFactor: 1
                            };

                            // draw lines from home to each data point
                            if (!!$scope.chartOptions['series_data']['points']) {
                                for (var k in $scope.chartOptions['series_data']['points']) {
                                    if ($scope.chartOptions['series_data']['points'].hasOwnProperty(k)) {
                                        var rPoint = $scope.chartOptions['series_data']['points'][k];
                                        var redline = new L.polyline([homeLatLng, new L.latLng(rPoint.lat, rPoint.lon)], lineConfig);
                                        markerGroup.addLayer(redline);
                                    }
                                }
                            }
                        }

                        // DONE DRAWING on the cluster group... add to the map
                        map.addLayer(markerGroup);

                    };
                }],

            link: function (scope, el, attrs, ctrl) {

                console.debug('lcioMap directive "link" called');

                // watch chartOptions for changes
                scope.$watchCollection('chartOptions', function (newVal) {
                    if (!!newVal) {
                        ctrl.redraw();
                    }
                });
            }
        };
    });
})();

