/* global angular */
/* global _ */

(function () {
    'use strict';

    angular.module('lcio.tw')
    .controller('AllConversationsController', ['$scope', '$log', '$modal', '$stateParams', '$eventSock', 'LoginService',
    function (scope, log, modal, stateParams, eventSock, LoginService) {

        log.info('Controller === AllConversationsController');

        scope.conversationsTree = {};
        LoginService.getLoginUser().then(function (loginUser) {
            if (loginUser === null) {
                log.error('Failed to get LoginUser, WebSocket cannot be initialized.');
            } else {
                var tenantId = loginUser.tenants[stateParams.activeTenantIndex]['id'];
                scope.activeTenantId = tenantId;

                eventSock.addStream('/allconversations', function (evt) {

                    log.debug('received an allConversations event from the websocket', evt);
                    if (angular.isUndefined(evt) || !angular.isObject(evt)) {
                        return;
                    }
                    log.debug('All Conversations update', evt);

                    var pciData = [];
                    var scopeColorClasses = ['bundle-node-pci-int-in', 'bundle-node-pci-ext-in'];
                    var ipScopes = ['InternalIn', 'ExternalIn'];


                    // This will be soon moved out in a factory as all conversations would also need it
                    function getFormattedIp(ip) {

                        var arr = ip.split('.');
                        var formattedIp = '';
                        var str = '';
                        var len = arr.length;

                        for (var j = 0; j < len; j ++) {

                            if (arr[j].length === 2) {
                                str = '0' + arr[j];
                            } else if (arr[j].length === 1) {
                                str = '00' + arr[j];
                            } else {
                                str = arr[j];
                            }

                            if (j < (len-1)) {
                                formattedIp = formattedIp + str + '.';
                            } else {
                                formattedIp = formattedIp + str;
                            }
                        }
                        return formattedIp;
                    }

                    var ipObj = {};
                    var formattedIpObject = {};

                    angular.forEach(evt, function (array, index) {

                        var scopeColorClass = scopeColorClasses[index];
                        var ipScope = ipScopes[index];
                        angular.forEach(array, function (obj) {
                            obj['scopeColorClass'] = scopeColorClass;
                            obj['ipScope'] = ipScope+','+obj['ip'];
                            obj['scope'] = ipScope;
                            ipObj[obj['ip']] = obj;
                            formattedIpObject[getFormattedIp(obj['ip'])] = obj;
                        });
                        Array.prototype.push.apply(pciData, array);
                    });

                    angular.forEach(pciData, function (array) {
                        for (var key in array.metrics) {
                           var obj = ipObj[key];

                           if (!obj) {

                              obj = {};
                              obj.metrics = {};
                              obj.ip = key;

                              var pattern = /^192.168/.test(obj.ip);
                              if (pattern) {
                                  obj.scope = ipScopes[0];
                                  obj.scopeColorClass = scopeColorClasses[0];
                              } else {
                                  obj.scope = ipScopes[1];
                                  obj.scopeColorClass = scopeColorClasses[1];
                              }

                              obj['ipScope'] = obj.scope+','+obj['ip'];
                              formattedIpObject[getFormattedIp(obj['ip'])] = obj;
                           }

                           var temp = array.metrics[key];
                           array.metrics[obj.scope+','+key] = temp;
                           delete array.metrics[key];
                        }
                    });

                    var inInkeys = [];
                    var inOutKeys = [];
                    var extInKeys = [];
                    var extOutKeys = [];

                    _.each(formattedIpObject, function (val, key) {

                        if (val.scope === 'ExternalIn') {
                            extInKeys.push(key);
                        } else if (val.scope === 'InternalIn') {
                            inInkeys.push(key);
                        }
                    });

                    extInKeys.sort();
                    inInkeys.sort();

                    var pciKeys = extInKeys.concat(inInkeys);

                    var pciArray = [];

                    for (var k = 0; k < pciKeys.length; k++) {
                        pciArray.push(formattedIpObject[pciKeys[k]]);
                    }


                    scope.conversationsTree = pciArray;
                    scope.$apply();
                }, tenantId);
            }
        });

        scope.openModal = function () {
            modal.open({
                templateUrl: 'templates/partials/modals/allconversations-modal.html',
                windowTemplateUrl: 'templates/partials/modals/dashboard-modal-root.html',
                scope: scope,
                backdrop: false
            });
        };

        scope.$on('$destroy', function () {
            eventSock.removeStream('/allconversations', scope.activeTenantId);
        });

    }]);
})();
