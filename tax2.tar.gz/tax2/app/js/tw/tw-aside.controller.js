/* global angular */

(function () {
    'use strict';
    angular.module('lcio.tw')
    .controller('TwAsideController', ['$scope', '$log', '$eventSock', '$modal', '$stateParams', 'LoginService',
    function (scope, log, eventSock, modal, stateParams, LoginService) {

        log.info('Controller === TwAsideController');

        scope.lcioAlertsData = {
            'alerts': []
        };
        LoginService.getLoginUser().then(function (loginUser) {
            if (loginUser === null) {
                log.error('Failed to get LoginUser, WebSocket cannot be initialized.');
            } else {
                var tenantId = loginUser.tenants[stateParams.activeTenantIndex]['id'];
                scope.activeTenantId = tenantId;
                eventSock.addStream('/alerts', function (evt) {
                    if (angular.isUndefined(evt) || !angular.isArray(evt)) {
                        return;
                    }

                    if (evt.length > 0) {
                        log.debug('update alerts', evt);
                        scope.lcioAlertsData.alerts = evt;
                        scope.$apply();
                    }
                }, tenantId);
            }
        });

        scope.openModal = function () {
            return modal.open({
                templateUrl:       'templates/partials/modals/alerts-modal.html',
                windowTemplateUrl: 'templates/partials/modals/dashboard-modal-root.html',
                scope: scope,
                backdrop: false
            });
        };

        scope.$on('$destroy', function () {
            eventSock.removeStream('/alerts', scope.activeTenantId);
        });
    }]);
})();

