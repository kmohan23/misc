/* global angular */

(function () {
    'use strict';

    angular.module('lcio.tw')
    .controller('GeomapController', ['$scope', '$log', '$eventSock', '$stateParams', '$modal', 'LoginService', 'ThreatService', '$timeout', '$interval',
    function (scope, log, eventSock, stateParams, modal, LoginService, ThreatService, timeout, interval) {

        log.info('Controller === Geomap');

        scope.masterPointList = {};
        scope.masterCountryList = {};

        scope.lcioMapOptions = {
            'series_data': {}
        };

        LoginService.getLoginUser().then(function (loginUser) {
            if (loginUser === null) {
                log.error('Failed to get LoginUser, WebSocket cannot be initialized.');
                return;
            }
            var tenantObj = loginUser.tenants[stateParams.activeTenantIndex];
            if (tenantObj === null) {
                log.error('Failed to find active tenant, cannot populate map.');
                return;
            }
            var tenantId = tenantObj['id'];
            scope.activeTenantId = tenantId;

            scope.lat = loginUser.geoData ? loginUser.geoData.lat : null;
            scope.lon = loginUser.geoData ? loginUser.geoData.lon : null;
            eventSock.addStream('/mapdata', function (evt) {
                //log.debug('received a mapdata event from websocket', evt);
                if (angular.isUndefined(evt) || !angular.isObject(evt)) {
                    log.debug('received invalid mapdata event from websocket', evt);
                    return;
                }
                log.debug('received /mapdata on the websocket', evt);

                if ('points' in evt) {
                    var index, len;
                    for (index = 0, len = evt.points.length; index < len; index++) {
                        var ip = evt.points[index]['addr'];

                        if (ip in scope.masterPointList) {
                        } else {
                            scope.masterPointList[ip] = {};
                            scope.masterPointList[ip]['type'] = 'point_unknown';
                        }

                        var keys = ['addr', 'code', 'host', 'lat', 'lon', 'name', 'z'];
                        for (var k = 0; k < keys.length; k++) {
                            scope.masterPointList[ip][keys[k]] = evt.points[index][keys[k]];
                        }

                        scope.masterPointList[ip]['reported'] = new Date();

                        if (scope.masterPointList[ip]['type'] === 'point_unknown') {
                            // log.debug('request threat info for [' + ip + ']');

                            // jshint loopfunc: true
                            ThreatService.ipThreatInfo(ip).then(function (result) {
                                var ip = result.ip;
                                var score = result.ciscoThreat.score;
                                // log.debug('response threat info for [' + ip + '] = ' + score);
                                if (ip in scope.masterPointList) {
                                    scope.masterPointList[ip]['score'] = score;
                                    var type = 'point_unknown';
                                    if (score === null) {
                                        type = 'point_noscore';
                                    } else {
                                        if (score <= -6.0) { type = 'point_high'; }
                                        else if (score <= 3.0) { type = 'point_medium'; }
                                        else { type = 'point_low'; }
                                    }
                                    // log.debug('setting color of point [' + ip + '] to ' + type);
                                    scope.masterPointList[ip]['type'] = type;
                                    scope.changes++;
                                }
                            });
                        }
                    }
                }

                scope.masterCountryList = evt.countries;

                // TODO - clean up stale points from scope.masterPointList (using 'reported' timestamp)
                scope.changes++;
            }, tenantId);
        });

        scope.changes = 1;

        var redrawMap = function () {
            if (scope.changes > 0) {
                log.debug('telling directive to redraw, changes=' + scope.changes);
                delete scope.lcioMapOptions['series_data'];
                scope.lcioMapOptions['series_data'] = {
                    'countries': scope.masterCountryList,
                    'points': scope.masterPointList,
                    'timestamp': new Date()
                };
                scope.changes = 0;
            } else {
                log.debug('no need to redraw');
            }
        };

        var drawInterval = interval(redrawMap, 1500);

        scope.openModal = function () {
            modal.open({
                templateUrl:       'templates/partials/modals/worldmap-modal.html',
                windowTemplateUrl: 'templates/partials/modals/dashboard-modal-root.html',
                scope: scope,
                backdrop: false
            });
        };

        scope.$on('$destroy', function () {
            eventSock.removeStream('/mapdata', scope.activeTenantId);
            interval.cancel(drawInterval);
        });
    }]);
})();

