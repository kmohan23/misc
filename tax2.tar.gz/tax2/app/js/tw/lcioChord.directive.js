/* global angular */
/* global d3 */
/* global _ */

(function () {
    'use strict';
    angular.module('lcio.tw')
    .directive('lcioChord', function () {
        return {
            scope: {
                conversationsTree: '='
            },
            controller: ['$scope', '$element', '$attrs', '$log',
            function (scope, element, attrs, log) {
                var tip = d3.tip()
                    .attr('class', 'd3-tip')
                    .offset([-10, 0]);

                this.redraw = function () {

                    if (!Array.isArray(scope.conversationsTree) || scope.conversationsTree.length === 0) {
                        /*log.debug('Printing Conversations Data');
                         log.debug(scope.conversationsTree);*/

                        return;
                    }

                    angular.element(element[0]).children().remove();

                    var diameter = 720,
                        radius = diameter / 2,
                        innerRadius = radius - 96;

                    var cluster = d3.layout.cluster()
                        .size([360, innerRadius])
                        .sort(null)
                        .value(function (d) {
                            return d.size;
                        });

                    var bundle = d3.layout.bundle();

                    var line = d3.svg.line.radial()
                        .interpolate('bundle')
                        .tension(0.85)
                        .radius(function (d) {
                            return d.y;
                        })
                        .angle(function (d) {
                            return d.x / 180 * Math.PI;
                        });

                    var svg = d3.select(element[0]).append('svg')
                        .attr('width', diameter)
                        .attr('height', diameter)
                        .append('g')
                        .attr('transform', 'translate(' + radius + ',' + radius + ')');

                    var link = svg.append('g').selectAll('.pci-bundle-link'),
                        node = svg.append('g').selectAll('.pci-bundle-node');

                    svg.call(tip);

                    function mouseovered(d) {

                        tip.html(
                            '<div><div>IP : '+d.key+'</div>' + (d.hostname !== null ? '<br><div>Host : '+d.hostname+'</div></div>' : '')
                            // TODO: this link to OpenDNS Investigative Services should only be visible to users with the correct entitlement
                            //'<br><div><a target="_blank" href="https://login.opendns.com/?return_to=https://dashboard2.opendns.com">OpenDNS Investigative Service</a></div></div>'
                        );

                        link
                            .classed('pci-bundle-link--target', function (l) {
                                if (l.target === d || l.source === d) {
                                    return true;
                                }
                            });

                        node
                            .classed('mouseover', tip.show);

                    }

                    function mouseouted() {

                        link
                            .classed('pci-bundle-link--target', false);

                        node.classed('mouseover', tip.hide);
                    }

                    function createRelationship(conversationsTree) {

                        var map = {};

                        function find(name, data) {

                            var node = map[name], i;

                            if (!node) {
                                node = map[name] = data || {name: name, children: []};
                                if (name.length) {

                                    node.parent = find(name.substring(0, i = name.lastIndexOf(',')));
                                    node.parent.children.push(node);
                                    node.name = name;
                                    node.key = name.substring(i + 1);
                                }
                            }
                            return node;
                        }

                        conversationsTree.forEach(function (d) {

                            find(d.ipScope, d);
                        });

                        return map[''];
                    }

                    function mapLinks(nodes) {

                        var map = {}, imports = [];

                        nodes.forEach(function (d) {
                            map[d.name] = d;
                        });

                        nodes.forEach(function (d) {

                            if (d.metrics) {
                                for (var key in d.metrics) {
                                    imports.push({source: map[d.name], target: map[key]});
                                }
                            }
                        });

                        return imports;
                    }

                    var nodes = cluster.nodes(createRelationship(scope.conversationsTree));
                    var links = mapLinks(nodes);


                    link = link
                        .data(bundle(links))
                        .enter().append('path')
                        .each(function (d) {

                            d.source = d[0];
                            d.target = d[d.length - 1];
                        })
                        .attr('class', function (d) {

                            if ((d.source.scopeColorClass === 'bundle-node-pci-int-in' || d.source.scopeColorClass === 'bundle-node-pci-ext-in') &&
                                (d.target.scopeColorClass === 'bundle-node-pci-int-out' || d.target.scopeColorClass === 'bundle-node-pci-ext-out')) {
                                return 'pci-bundle-link-in-out';
                            } else {
                                return 'pci-bundle-link';
                            }
                        })
                        .attr('stroke-width', function (d) {

                            var metrics = d.source.metrics[d.target.ipScope];
                            if (metrics && metrics.hasOwnProperty('TotalBytes')) {

                                var totalBytes = metrics['TotalBytes'];
                                if (totalBytes <= 100) {
                                    return '1px';
                                } else if (totalBytes > 100 && totalBytes <= 1000) {
                                    return '2px';
                                } else {
                                    return '3px';
                                }
                            } else {
                                return '1px';
                            }
                        })
                        .attr('d', line);

                    node = node
                        .data(nodes.filter(function (n) {
                            return !n.children;
                        }))
                        .enter().append('text')
                        .attr('class', function (d) {
                            return 'pci-bundle-node ' + d.scopeColorClass;
                        })
                        .attr('dy', '.31em')
                        .attr('transform', function (d) {
                            return 'rotate(' + (d.x - 90) + ')translate(' + (d.y + 8) + ',0)' + (d.x < 180 ? '' : 'rotate(180)');
                        })
                        .style('text-anchor', function (d) {
                            return d.x < 180 ? 'start' : 'end';
                        })
                        .text(function (d) {
                            return d.key;
                        })
                        .on('mouseover', mouseovered)
                        .on('mouseout', mouseouted);
                };
            }],

            link: function (scope, el, attrs, ctrl) {
                scope.$watch('conversationsTree', function () {
                    ctrl.redraw();
                });
            }
        };
    });
})();
