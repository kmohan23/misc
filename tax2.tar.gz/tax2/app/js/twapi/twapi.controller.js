/* global angular */

(function () {
    'use strict';

    angular.module('lcio.twapi')
    .controller('TwApiController', ['$scope', '$log', '$http',
    function (scope, log, http) {

        log.info('Controller === TwApiController');

        scope.apiwadl = 'loading...';

        http({
            method: 'GET',
            url: '/model/application.wadl'
        }).then(function successCallback(response) {
            // this callback will be called asynchronously
            // when the response is available
            scope.apiwadl = response.data;
        }, function errorCallback(response) {
            // called asynchronously if an error occurs
            // or server returns response with an error status.
            scope.setWithTimeout('formErrorString', 'Could not fetch API details: ' + response.error);
        });
    }]);
})();

