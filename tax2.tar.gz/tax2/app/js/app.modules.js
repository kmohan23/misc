/* global angular */

(function () {
    'use strict';

    var appName = 'lcio';
    var appModules = {
        login:    [],
        partner:  [],
        swpci:    [],
        twapi:    [],
        tw:       [],
        twdetail: [],
        opendns:  [],
        cta:      [],
        templates: []
    };

    var aMods = [];
    for (var appMod in appModules) {
        var modName = appName + '.' + appMod;
        aMods.push(modName);
        angular.module(modName, appModules[appMod]);
    }
    angular.module(appName + '.modules', aMods);
})();

