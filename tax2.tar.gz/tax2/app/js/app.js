/* global angular */
/* global window */

(function () {
    'use strict';

    angular.module('lcio', [
        'ngCookies',
        'ngResource',
        'ngSanitize',
        //'ngAnimate',
        'ui.utils',
        'ui.bootstrap',
        'ui.router',
        'ui.grid',
        'ui.grid.autoResize',
        'ui.grid.cellNav',
        'ui.grid.edit',
        'ui.grid.expandable',
        'ui.grid.rowEdit',
        'blockUI',
        'lcio.modules'
    ])

    .constant('WSURL', 'ws://' + window.location.host + '/model/event/')

    // Dev
    //.constant('WSURL', 'wss://internal-dev-webfrontend-1768109771.us-west-2.elb.amazonaws.com/model/event/')

    // QA
    //.constant('WSURL', 'wss://internal-qa-webfrontend-1703056165.us-west-2.elb.amazonaws.com/model/event/')


    .config(['$locationProvider', '$httpProvider', '$stateProvider', '$urlRouterProvider', '$logProvider', 'blockUIConfig',
        function (locationProvider, httpProvider, stateProvider, urlRouterProvider, logProvider, blockUIConfig) {
            logProvider.debugEnabled(true);

            stateProvider

                .state('login', {
                    url: '',
                    abstract: true,
                    views: {
                        'app-header': {
                            templateUrl: 'templates/login/lc-login-header.html',
                            controller: 'LoginHeaderController'
                        },
                        '@': {
                            templateUrl: 'templates/login/login.html',
                            controller: 'LoginController'
                        },
                        'app-footer': {
                            templateUrl: 'templates/login/lc-login-footer.html'
                        }
                    },
                    params: {
                        requireLogin: false
                    }
                })
                .state('login.login', {
                    url: '/login',
                    views: {
                        'formView': {
                            templateUrl: 'templates/login/formLogin.html'
                        }
                    },
                    params: {
                        toState:  { value: 'screen.home' },
                        toParams: { value: {} }
                    }
                })
                .state('login.register', {
                    url: '/register',
                    views: {
                        'formView': {
                            templateUrl: 'templates/login/formRegisterPassforgot.html'
                        }
                    }
                })
                .state('login.verify', {
                    url: '/verify/:id?t',
                    views: {
                        'formView': {
                            templateUrl: 'templates/login/formVerifyReset.html'
                        }
                    }
                })
                .state('login.passforgot', {
                    url: '/passforgot',
                    views: {
                        'formView': {
                            templateUrl: 'templates/login/formRegisterPassforgot.html'
                        }
                    }
                })
                .state('login.reset', {
                    url: '/reset/:id?t',
                    views: {
                        'formView': {
                            templateUrl: 'templates/login/formVerifyReset.html'
                        }
                    },
                    params: {
                        requireLogin: false
                    }
                })

                .state('screen', {
                    url: '',
                    abstract: true,
                    views: {
                        'app-header': {
                            templateUrl: 'templates/partials/screenheader/lc-screen-header.html',
                            controller: 'ScreenHeaderCtrl'
                        },
                        '@': {
                            templateUrl: 'templates/screens/screen.html'
                        }
                    },
                    params: {
                        requireLogin: true,
                        activeTenantIndex : 0
                    }
                })
                .state('screen.home', {
                    url: '/home',
                    views: {
                        '@': {
                            controller: 'ScreenHeaderCtrl'
                        }
                    }
                })
                .state('screen.twdetail', {
                    url: '/twdetail',
                    views: {
                        'asideView': {
                            templateUrl: 'templates/screens/twdetail/aside.html',
                            controller: 'TwDetailAsideController'
                        },
                        'mainView': {
                            templateUrl: 'templates/screens/twdetail/main.html',
                            controller: 'TwDetailController'
                        }
                    },
                    params: {
                        name : 'StealthWatch Cloud Detail'
                    }
                })
                .state('screen.tw', {
                    url: '',
                    abstract: true,
                    views: {
                        'asideView': {
                            templateUrl: 'templates/screens/tw/aside.html',
                            controller: 'TwAsideController'
                        },
                        'mainView': {
                            templateUrl: 'templates/screens/tw/main.html'
                        }
                    },
                    params: {
                        name : 'StealthWatch Cloud'
                    }
                })
                .state('screen.tw.home', {
                    url: '/trafficwatch',
                    views: {
                        'chartView': {
                            templateUrl: 'templates/screens/tw/chartAllConvos.html',
                            controller: 'AllConversationsController'
                        }
                    }
                })
                .state('screen.tw.geomap', {
                    url: '/geomap',
                    views: {
                        'chartView': {
                            templateUrl: 'templates/screens/tw/chartMap.html',
                            controller: 'GeomapController'
                        }
                    }
                })
                .state('screen.swpci', {
                    url: '/swpci',
                    views: {
                        'asideView': {
                            templateUrl: 'templates/screens/tw/aside.html',
                            controller: 'TwAsideController'
                        },
                        'mainView': {
                            templateUrl: 'templates/screens/swpci/main.html',
                            controller: 'SwPciController'
                        }
                    },
                    params: {
                        name : 'StealthWatch Cloud for PCI'
                    }
                })
                .state('screen.twapi', {
                    url: '/twapi',
                    views: {
                        'asideView': {
                            templateUrl: 'templates/screens/tw/aside.html',
                            controller: 'TwAsideController'
                        },
                        'mainView': {
                            templateUrl: 'templates/screens/twapi/main.html',
                            controller: 'TwApiController'
                        }
                    },
                    params: {
                        name : 'StealthWatch Cloud API'
                    }
                })
                .state('screen.opendns', {
                    url: '/opendns',
                    views: {
                        '@': {
                            templateUrl: 'templates/screens/opendns/openDNS.html'
                        }
                    },
                    params: {
                        name: 'OpenDNS Umbrella'
                    }
                })
                .state('screen.cta', {
                    url: '/cta',
                    views: {
                        '@': {
                            templateUrl: 'templates/screens/cta/cognitiveThreatAnalytics.html'
                        }
                    },
                    params: {
                        name: 'Cognitive Threat Analysis'
                    }
                })
                .state('screen.partnerhome', {
                    url: '/partnerhome',
                    views: {
                        'asideView': {
                            templateUrl: 'templates/screens/partner/partnerhome/aside.html',
                            controller: 'PartnerHomeAsideController'
                        },
                        'mainView': {
                            templateUrl: 'templates/screens/partner/partnerhome/main.html',
                            controller: 'PartnerHomeController'
                        }
                    },
                    params: {
                        name : 'StealthWatch Cloud MSP Console'
                    }
                })
                .state('screen.partnerdetail', {
                    url: '/partnerdetail',
                    views: {
                        'asideView': {
                            templateUrl: 'templates/screens/partner/partnerdetail/aside.html',
                            controller: 'PartnerDetailAsideController'
                        },
                        'mainView': {
                            templateUrl: 'templates/screens/partner/partnerdetail/main.html',
                            controller: 'PartnerDetailController'
                        }
                    },
                    params: {
                        name : 'StealthWatch Cloud MSP Console Detail'
                    }
                })
                .state('screen.partneropendns', {
                    url: '/partneropendns',
                    views: {
                        '@': {
                            templateUrl: 'templates/screens/partner/partnerOpenDNS.html',
                            controller: 'PartnerDetailController'
                        }
                    },
                    params: {
                        name : 'OpenDNS MSP Console'
                    }
                });


            blockUIConfig.message = '';
            blockUIConfig.templateUrl = 'templates/partials/block-ui-overlay.html';

            locationProvider.hashPrefix('!');

            urlRouterProvider.deferIntercept();
            urlRouterProvider.when('/', '/home');

            // This is required for Browser Sync to work properly
            httpProvider.defaults.headers.common['X-Requested-With'] = 'XMLHttpRequest';

        }
    ])

//==============================================================================

    .run(['$rootScope', '$state', '$stateParams', '$urlRouter', '$log', 'LoginService',
    function (rootScope, state, stateParams, urlRouter, log, LoginService) {

        log.debug('Angular.js run() function...', state, stateParams);
        rootScope.globals = {};
        rootScope.$state = state;
        rootScope.$stateParams = stateParams;

        // 'Handle top-level URL, i.e. /'
        if (state.current.url === '^') {
            state.go('login.login', stateParams);
        }

        rootScope.$on('$stateChangeStart', function (event, toState, toParams) {
            log.debug('ui-router state change:');
            log.debug('    To: ', toState, toParams);
            if (toParams.hasOwnProperty('requireLogin') && toParams['requireLogin'] === true) {
                LoginService.checkLogin().then(function (loggedIn) {
                    if (loggedIn !== true) {
                        event.preventDefault();
                        log.debug('page required login, but user is not logged in');
                        state.go('login.login', {toState: toState, toParams: toParams});
                    }
                });
            }
        });
        urlRouter.listen();
    }]);
})();

