/* global angular */
/* global _ */

(function () {
    'use strict';

    angular.module('lcio.opendns')
        .controller('OpenDnsController', ['$scope', '$log', '$modal', '$stateParams', '$eventSock', 'LoginService',
            function (scope, log, modal, stateParams, eventSock, LoginService) {


                log.info('Controller === OpenDnsController');
            }]);

})();
