/* global angular */

(function () {
    'use strict';

    angular.module('lcio')
    .factory('ThreatService', ['$q', '$log', '$eventSock', function (q, log, eventSock) {
        var cacheCleanSeconds = 5 * 60;
        var cacheExpirationSeconds = 60 * 60;
        var nextCacheCleanTime = new Date();
        var ipThreatCache = {};
        var deferredQueue = {};
        eventSock.addStream('/slic', function (data, ctx) {
            if (angular.isUndefined(data) || !angular.isObject(data)) {
                log.error('Invalid slic event', data, ctx);
                return;
            }
            var ip = ctx.split('.').map(Number).join('.');
            var threatInfo = angular.copy(data);
            threatInfo.writeTimestamp = new Date();
            ipThreatCache[ip] = threatInfo;
            if (deferredQueue.hasOwnProperty(ip)) {
                deferredQueue[ip].forEach(function (deferred) {
                    deferred.resolve(threatInfo);
                });
                delete deferredQueue[ip];
            } else {
                log.debug('slic/' + ip + ' had no deferred.');
            }
        });

        function cleanCache() {
            var now = new Date();
            if (now > nextCacheCleanTime) {
                for (var ip in ipThreatCache) {
                    if (ipThreatCache.hasOwnProperty(ip)) {
                        if (((now - ipThreatCache[ip].writeTimestamp) / 1000) > cacheExpirationSeconds) {
                            log.debug('cleanCache : removing old entry for slic/' + ip);
                            delete ipThreatCache[ip];
                        }
                        if (ipThreatCache[ip].hasOwnProperty('readTimestamp')) {
                            if (((now - ipThreatCache[ip].readTimestamp) / 1000) > cacheCleanSeconds) {
                                log.debug('cleanCache : removing unused entry for slic/' + ip);
                                delete ipThreatCache[ip];
                            }
                        }
                    }
                }
                nextCacheCleanTime = new Date(now.getTime() + (cacheCleanSeconds * 1000));
            }
        }
        return {
            ipThreatInfo: function (ip) {
                var deferred = q.defer();
                var cleanIp  = ip.split('.').map(Number).join('.');
                deferred.resolve({ip: ip, ciscoThreat: {score: null}});

                //if (cleanIp in ipThreatCache) {
                //    var cached = ipThreatCache[cleanIp];
                //    cached.readTimestamp = new Date();
                //    ipThreatCache[cleanIp] = cached;
                //    log.debug('slic/' + cleanIp + ' cache hit, = ', cached);
                //    deferred.resolve(cached);
                //} else {
                //
                //    console.log('Printing Read Stream');
                //    eventSock.readStream('/slic', cleanIp);
                //    if (!deferredQueue.hasOwnProperty(cleanIp)) {
                //        deferredQueue[cleanIp] = [];
                //    }
                //    deferredQueue[cleanIp].push(deferred);
                //}
                //cleanCache();
                return deferred.promise;
            }
        };
    }]);
})();

