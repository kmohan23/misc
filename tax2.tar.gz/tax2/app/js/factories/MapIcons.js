/* global angular */
/* global L */

(function () {
    'use strict';

    angular.module('lcio')
    .factory('MapIcons',
    function () {

        var RedIcon = L.Icon.Default.extend({
            options: {
                iconUrl: 'images/map-pin-red.png'
            }
        });

        var redIcon = new RedIcon();

        var GreenIcon = L.Icon.Default.extend({
            options: {
                iconUrl: 'images/map-pin-green.png'
            }
        });

        var greenIcon = new GreenIcon();

        var YellowIcon = L.Icon.Default.extend({
            options: {
                iconUrl: 'images/map-pin-yellow.png'
            }
        });

        var yellowIcon = new YellowIcon();

        return {

            /* Call this function with respective threat data color that's it*/
            getIcon: function (color) {

                switch (color) {
                    case 'Red':
                        return redIcon;
                    case 'Green':
                        return greenIcon;
                    case 'Yellow':
                        return yellowIcon;
                }
            }
        };
    });
})();

