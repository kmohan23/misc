/* global angular */

(function () {
    'use strict';

    angular.module('lcio')
    .factory('ApplianceDownloadFactory', ['$modal', '$timeout', '$window', '$log', 'ResourceFactory', 'LoginService',
    function (modal, timeout, window, log, ResourceFactory, LoginService) {

        var loginUser = {};
        LoginService.getLoginUser().then(function (luser) {
            loginUser = luser;
        });

        function startDownload() {

            var timeoutVar;

            var modalInstance = modal.open({
                templateUrl: 'templates/partials/modals/controlstatement.html',
                backdrop: 'static',
                keyboard: false
            });

            modalInstance.result.then(function (value) {
                if (value === 'StartDownload') {
                    if (angular.isDefined(timeoutVar)) {
                        timeout.cancel(timeoutVar);
                        timeoutVar = undefined;
                        window.location.href = '/model/assets/LancopeIoAppliance.ova';
                    }
                }
            }, function () {
                log.info('Modal dismissed at: ' + new Date());
            });

            modalInstance.opened.then(function () {
                timeoutVar = timeout(function () {

                    modalInstance.dismiss('dismissed');
                    window.location.href = '/model/assets/LancopeIoAppliance.ova';
                }, 60000);
            }, function () {
                log.info('Modal dismissed at: ' + new Date());
            });
        }

        return {

            decideDownload: function () {

                ResourceFactory.ExportCompliance().get().$promise.then(function (data) {

                    if (data.success) {
                        startDownload();
                    } else {
                        if (typeof data.message === 'string') {

                            modal.open({

                                templateUrl: 'templates/partials/modals/unauthorized.html',
                                controller: 'UnAuthorizedModalInstanceCtrl',
                                resolve: {
                                    errMsg: function () {
                                        return data.message;
                                    }
                                },
                                backdrop: 'static',
                                keyboard: false
                            });
                        } else {

                            var modalInstance = modal.open({

                                templateUrl: 'templates/partials/modals/userProfile.html',
                                controller: 'UserProfileModalInstanceCtrl',
                                resolve: {
                                    fromType: function () {
                                        return 'from-appliance-download';
                                    }
                                },
                                backdrop: 'static',
                                keyboard: false
                            });
                            modalInstance.opened.then(function () {
                                modalInstance.setMyData(data.message);
                            }, function () {
                                log.info('Modal dismissed at: ' + new Date());
                            });
                        }
                    }
                });
            }
        };
    }]);
})();
