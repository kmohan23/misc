/* global angular */

(function () {
    'use strict';

    angular.module('lcio')
    .factory('GeoService', ['$q', '$log', '$eventSock', function (q, log, eventSock) {
        var cacheCleanSeconds = 60 * 60;
        var cacheExpirationSeconds = 60 * 60 * 24;
        var nextCacheCleanTime = new Date();
        var geoCache = {};
        var deferredQueue = {};

        function resolveDeferrals (key, result, failed) {
            if (deferredQueue.hasOwnProperty(key)) {
                deferredQueue[key].forEach(function (d) {
                    if (failed) {
                        d.reject(result);
                    } else {
                        d.resolve(result);
                    }
                });
                delete deferredQueue[key];
            } else {
                log.debug('Key had no deferred.', key);
            }
        }
        function cleanCache() {
            var now = new Date();
            if (now > nextCacheCleanTime) {
                for (var ip in geoCache) {
                    if (geoCache.hasOwnProperty(ip)) {
                        if (((now - geoCache[ip].writeTimestamp) / 1000) > cacheExpirationSeconds) {
                            log.debug('cleanCache : removing old entry geo/' + ip);
                            delete geoCache[ip];
                        }
                        if (geoCache[ip].hasOwnProperty('readTimestamp')) {
                            if (((now - geoCache[ip].readTimestamp) / 1000) > cacheCleanSeconds) {
                                log.debug('cleanCache : removing unused entry geo/' + ip);
                                delete geoCache[ip];
                            }
                        }
                    }
                }
                nextCacheCleanTime = new Date(now.getTime() + (cacheCleanSeconds * 1000));
            }
        }

        eventSock.addStream('/geo', function (data, ctx) {
            if (angular.isUndefined(data) || !angular.isObject(data)) {
                log.error('Invalid geo event', data, ctx);
                return;
            }
            var ip = ctx.split('.').map(Number).join('.');
            var geoInfo = angular.copy(data);
            geoInfo.writeTimestamp = new Date();
            geoCache[ip] = geoInfo;
            resolveDeferrals(ip, geoInfo);
        });

        eventSock.addStream('/geozip', function (data, ctx) {
            if (angular.isUndefined(data) || !angular.isObject(data)) {
                log.error('Invalid geozip event', data, ctx);
                return;
            }
            var zip = [ctx['country'], ctx['postalCode']].join('.');
            var geoInfo = angular.copy(data);
            geoInfo.writeTimestamp = new Date();
            geoCache[zip] = geoInfo;
            resolveDeferrals(zip, geoInfo);
        });

        return {
            ipGeoInfo: function (ip) {
                var deferred = q.defer();
                var cleanIp  = ip.split('.').map(Number).join('.');

                if (cleanIp in geoCache) {
                    var cached = geoCache[cleanIp];
                    cached.readTimestamp = new Date();
                    geoCache[cleanIp] = cached;
                    log.debug('geo/' + cleanIp + ' cache hit,', cached);
                    deferred.resolve(cached);
                } else {
                    eventSock.readStream('/geo', cleanIp);
                    if (!deferredQueue.hasOwnProperty(cleanIp)) {
                        deferredQueue[cleanIp] = [];
                    }
                    deferredQueue[cleanIp].push(deferred);
                }
                cleanCache();
                return deferred.promise;
            },
            zipGeoInfo: function (country, postalCode) {
                var deferred = q.defer();
                if (!country || !postalCode) {
                    log.error('Invalid country or zip.', country, postalCode);
                    deferred.reject('Invalid country or postalCode.');
                }
                var zip = [country, postalCode].join('.');
                if (zip in geoCache) {
                    var cached = geoCache[zip];
                    cached.readTimestamp = new Date();
                    geoCache[zip] = cached;
                    log.debug('geozip' + zip + ' cache hit,', cached);
                    deferred.resolve(cached);
                } else {
                    eventSock.readStream('/geozip', {country: country, postalCode: postalCode});
                    if (!deferredQueue.hasOwnProperty(zip)) {
                        deferredQueue[zip] = [];
                    }
                    deferredQueue[zip].push(deferred);
                }
                cleanCache();
                return deferred.promise;
            }
        };
    }]);
})();

