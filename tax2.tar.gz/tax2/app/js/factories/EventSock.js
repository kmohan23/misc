/* global angular */
/* global JSON */
/* global _ */
/* global ReconnectingWebSocket */
/* jslint bitwise: true */

(function () {
    'use strict';
    function EventSock(q, log, url) {
        var STREAMOPS   = '/streamops';
        var ALL_CONTEXT = '*';
        var listeners = {};
        var socket = null;
        var openSocket = q.defer();
        var guid = function () {
            var currentMS = new Date().getTime();
            return 'xxxxxxxx-xxxx-4xxx-yxxx-xxxxxxxxxxxx'.replace(/[xy]/g, function (currentChar) {
                var randomChar = (currentMS + Math.random() * 16) % 16|0;
                currentMS = Math.floor(currentMS / 16);
                return (currentChar === 'x' ? randomChar : (randomChar&0x7|0x8)).toString(16);
            });
        };
        function OpsMsg(stream, op, context) {
            return [stream, op, context, guid()];
        }
        function streamOpsCallback(evt, ctx) {
            if (angular.isUndefined(evt) || !angular.isArray(evt) || evt.length !== 3) {
                log.error('Invalid streamops event', evt, ctx);
                return;
            }
            //var soMsg  = evt[0];
            //var status = evt[1];
            //var stream = soMsg[0];
            //log.debug('Streamops status ' + status + ' for ' + stream + '/' + ctx, soMsg);
        }
        function registerStreams(self) {
            var currListeners = angular.copy(listeners);
            listeners = {};
            _.map(currListeners, function (cObj, s) {
                _.map(cObj, function (cList, c) {
                    _.each(cList, function (cb) {
                        log.debug('Re-adding stream/context listener ' + s + '/' + c);
                        self.addStream(s, cb, c);
                    });
                });
            });
            socket.reset = false;
        }
        function getSocket(eventObj) {
            if (!socket) {
                var sock = new ReconnectingWebSocket(url);

                sock.onopen = function () {
                    log.debug('WebSocket open...', this);
                    if (this.reset) {
                        log.debug('Re-registering streams ...');
                        registerStreams(eventObj);
                    }
                    openSocket.resolve(this);
                };
                sock.onclose = function () {
                    log.debug('Peer closed WebSocket:');
                    // if (!!socket) {
                    this.reset = true;
                    openSocket = q.defer();
                    // }
                };
                sock.onmessage = function (evt) {
                    if (evt.type !== 'message') {
                        log.warn('Received unexpected event type in onmessage(), ' + evt.type);
                    } else {
                        var msg = JSON.parse(evt.data);
                        log.debug('event message', msg);
                        var stream  = msg[0];
                        var context = msg[1];
                        var msgdata = msg[2];
                        if (listeners.hasOwnProperty(stream) && listeners[stream].hasOwnProperty(ALL_CONTEXT)) {
                            for (var i = 0; i < listeners[stream][ALL_CONTEXT].length; i++) {
                                log.debug('Calling listener ' + stream + '/' + ALL_CONTEXT);
                                listeners[stream][ALL_CONTEXT][i].apply(null, [msgdata, context]);
                            }
                        }
                        if (listeners.hasOwnProperty(stream) && listeners[stream].hasOwnProperty(context)) {
                            for (var j = 0; j < listeners[stream][context].length; j++) {
                                log.debug('Calling listener ' + stream + '/' + context);
                                listeners[stream][context][j].apply(null, [msgdata, context]);
                            }
                        }
                    }
                };
                socket = sock;
            }
            return socket;
        }
        return {
            start: function () {
                var self = this;
                if (!url) {
                    log.warn('URL is not set.');
                    return;
                }
                if (!socket) {
                    getSocket(self);
                    this.addStream(STREAMOPS, streamOpsCallback);
                }
                return openSocket.promise;
            },
            stop: function () {
                if (!!socket) {
                    socket.close();
                }
                socket    = null;
                listeners = {};
            },
            isConnected: function () {
                return openSocket.isResolved;
            },
            addStream: function (stream, t) {
                var context = ALL_CONTEXT;
                if (arguments.length > 2) {
                    context = arguments[2];
                }
                if (!listeners.hasOwnProperty(stream)) {
                    listeners[stream] = {};
                }
                if (!listeners[stream].hasOwnProperty(context)) {
                    listeners[stream][context] = [];
                }
                listeners[stream][context].push(t);

                log.debug('Adding listener: ' + stream + '/' + context + ', ' + listeners[stream][context].length);
                if (context !== ALL_CONTEXT) {
                    this.readStream(stream, context);
                    return this.doSendAsync(
                        new OpsMsg(stream, 'create', context) // Subscribe for updates
                    );
                }
                return q.defer();
            },
            removeStream: function (stream) {
                var context = ALL_CONTEXT;
                if (arguments.length > 1) {
                    context = arguments[1];
                }
                if (listeners.hasOwnProperty(stream)) {
                    if (listeners[stream].hasOwnProperty(context)) {
                        log.debug('Removing listener: ' + stream + '/' + context + ', ' + listeners[stream][context].length);
                        delete listeners[stream][context];
                        return this.doSendAsync(
                            new OpsMsg(stream, 'delete', context)
                        );
                    }
                }
            },
            readStream: function (stream, context) {
                log.debug('Read stream/context: ' + stream + '/' + context);
                return this.doSendAsync(
                    new OpsMsg(stream, 'read', context)
                );
            },
            doSend: function (msg) {
                return openSocket.promise.then(function (sock) {
                    //log.debug('Sending WS msg:', msg);
                    return sock.send(JSON.stringify(msg));
                });
            },
            doSendAsync: function (msg) {
                return _.defer(function (data, self) {
                    return self.doSend(data);
                }, msg, this);
            }
        };
    }

    angular.module('lcio')
    .provider('$eventSock', ['WSURL', function (url) {
        this.$get = ['$q', '$log', function (q, log) {
            return new EventSock(q, log, url);
        }];
    }]);
})();
