/* global angular */

(function () {
    'use strict';

    angular.module('lcio')
    .factory('ResourceFactory', ['$resource',
    function (resource) {
        return {
            Activate: function (resOpts) {
                return resource('/model/user/activate/:token', resOpts, {
                    'update': {
                        method: 'PUT'
                    }
                });
            },
            Appliance: function (resOpts) {
                return resource('/model/appliance/:id/:action', resOpts, {
                    'update': {
                        method: 'PUT'
                    },
                    'instances': {
                        method: 'GET',
                        isArray: true,
                        params: {action: 'instances'}
                    }
                });
            },
            ApplianceInstance: function (resOpts) {
                return resource('/model/applianceinstance/:id', resOpts, {
                    'update': {
                        method: 'PUT'
                    }
                });
            },
            Analytics: function (resOpts) {
                return resource('/model/analytics/:id', resOpts);
            },
            Customer: function (resOpts) {
                return {
                    listCustomers: resource('/model/customer', resOpts),
                    createCustomer: resource('/model/customer/create', resOpts)
                };
            },
            CustomerProfile: function (resOpts) {
                return resource('/model/customer/:custId/profile', resOpts, {
                    'get': {
                        method: 'GET',
                        isArray: true
                    },
                    'update': {
                        method: 'PUT'
                    }
                });
            },
            ExportCompliance: function (resOpts) {
                return resource('/model/user/export/check', resOpts);
            },
            Eula: function (resOpts) {
                return resource('/model/user/eula', resOpts);
            },
            Features: function (resOpts) {
                return resource('/model/settings/features/:name', resOpts, {
                    'list': {
                        method: 'GET',
                        isArray: false
                    }
                });
            },
            GetLicense: function (resOpts) {
                return resource('/model/tenant/licenses', resOpts);
            },
            Help: function (resOpts) {
                return resource('/model/user/:action', resOpts, {
                    emailHelp: {
                        method: 'POST',
                        params: {action: 'emailhelp'}
                    },
                    emailSalesHelp: {
                        method: 'POST',
                        params: {action: 'emailsales'}
                    }
                });
            },
            Login: function (resOpts) {
                return resource('/model/user/login', resOpts);
            },
            PartnerFulfillment: function (resOpts) {
                return resource('/model/partner/fulfillment/customer/:id', resOpts);
            },
            PartnerProfile: function (resOpts) {
                return resource('/model/partner/profile', resOpts, {
                    'get': {
                        method: 'GET',
                        isArray: true
                    },
                    'update': {
                        method: 'PUT'
                    }
                });
            },
            PassForgot: function (resOpts) {
                return resource('/model/user/passforgot', resOpts);
            },
            PassReset: function (resOpts) {
                return resource('/model/user/passreset/:id', resOpts);
            },
            Registration: function (resOpts) {
                return resource('/model/user/registration', resOpts);
            },
            Session: function (resOpts) {
                return resource('/model/user/session', resOpts);
            },
            Settings: function (resOpts) {
                return resource('/model/settings/:name', resOpts, {
                    'list': {
                        method: 'GET',
                        isArray: false
                    }
                });
            },
            Tenant: function (resOpts) {
                return resource('/model/tenant/:id', resOpts, {
                    update: {
                        method: 'PUT'
                    }
                });
            },
            User: function (resOpts) {
                return resource('/model/user/:id', resOpts, {
                    search: {
                        method: 'GET',
                        params: {email: '@email'},
                        isArray: true
                    },
                    update: {
                        method: 'PUT'
                    }
                });
            },
            UserProfile: function (resOpts) {
                return resource('/model/user/profile', resOpts, {
                    'get': {
                        method: 'GET',
                        isArray: true
                    },
                    'update': {
                        method: 'PUT'
                    }
                });
            },
            Verify: function (resOpts) {
                return resource('/model/user/verify/:id', resOpts);
            }
        };
    }]);
})();
