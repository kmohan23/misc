/* global angular */

(function () {
    'use strict';
    angular.module('lcio.partner')
        .controller('PartnerDetailAsideController', ['$scope', '$log', '$eventSock', '$modal', '$stateParams', 'LoginService',
            function (scope, log, eventSock, modal, stateParams, LoginService) {

                log.info('Controller === PartnerDetailAsideController');

            }]);
})();

