/* global angular */

(function () {
    'use strict';
    angular.module('lcio.partner')
    .controller('PartnerDetailController', ['$scope', '$log', '$eventSock', '$modal', '$stateParams', 'LoginService',
    function (scope, log, eventSock, modal, stateParams, LoginService) {

        log.info('Controller === PartnerDetailController');

        scope.lcioInternalUniqueIpsTrendOptions = {
            'series_data': [],
            'series_pointInterval': 0,
            'series_pointStart': 0
        };

        scope.currentLicenseMetric = [];

        LoginService.getLoginUser().then(function (loginUser) {
            if (loginUser === null) {
                log.error('Failed to get LoginUser, WebSocket cannot be initialized.');
            } else {
                var partnerId = loginUser.partner['id'];
                scope.activePartnerId = partnerId;
                eventSock.addStream('/internalUniqueIps', function (evt) {
                    if (angular.isUndefined(evt) || !angular.isObject(evt)) {
                        return;
                    }
                    log.debug('update stitchedflows');
                    scope.lcioInternalUniqueIpsTrendOptions['hasCurrentData']       = scope.currentLicenseMetric.length > 0;
                    scope.lcioInternalUniqueIpsTrendOptions['series_data']          = evt.data;
                    scope.lcioInternalUniqueIpsTrendOptions['series_data']          = scope.lcioInternalUniqueIpsTrendOptions['series_data'].concat(scope.currentLicenseMetric);
                    scope.lcioInternalUniqueIpsTrendOptions['series_pointInterval'] = evt.pointInterval;
                    scope.lcioInternalUniqueIpsTrendOptions['series_pointStart']    = evt.pointStart;
                    scope.lcioInternalUniqueIpsTrendOptions['actual_license_size']  = (loginUser.tenants[stateParams.activeTenantIndex]) ?
                                                                                      (loginUser.tenants[stateParams.activeTenantIndex].license ? loginUser.tenants[stateParams.activeTenantIndex].license.size : 0)
                                                                                      : 0;
                    scope.$apply();
                }, partnerId);

                eventSock.addStream('/currentLicenseMetric', function (evt) {
                    if (angular.isUndefined(evt) || !angular.isObject(evt)) {
                        return;
                    }
                    log.debug('printing currentLicenseMetric ' + evt);
                    scope.currentLicenseMetric = evt.data;
                    scope.$apply();
                }, partnerId);
            }
        });

        scope.$on('$destroy', function () {
            var partnerId = scope.activePartnerId;
            eventSock.removeStream('/internalUniqueIps', partnerId);
            eventSock.removeStream('/currentLicenseMetric', partnerId);
        });
    }]);
})();

