/* global angular */
/* jshint loopfunc: true */

(function () {
    'use strict';

    angular.module('lcio.partner')
    .controller('PartnerHomeController', ['$scope', '$log', '$modal', 'LoginService', 'GeoService', '$templateCache', 'ResourceFactory', '$rootScope',
    function (scope, log, modal, LoginService, GeoService, templateCache, ResourceFactory, rootScope) {

        log.info('Controller === PartnerHomeController');

        LoginService.getLoginUser().then(function (loginUser) {
            if (loginUser === null) {
                log.error('Failed to get LoginUser, WebSocket cannot be initialized.');
            } else {
                ResourceFactory.User().get(loginUser).$promise.then(function (data) {
                    var myPartnerLocation;
                    GeoService.zipGeoInfo(data.partner.country, data.partner.postalCode).then(function (gInfo) {
                        myPartnerLocation = gInfo;
                        rootScope.$broadcast('partnerLocation', myPartnerLocation);
                    });
                });
            }
        });

        scope.lcioMapOptions = {
            'map_data': [],
            'template': null
        };

        scope.lcioMapOptions.template = templateCache.get('partner-map-popup.html');

        scope.openModal = function (type) {

            var tempUrl = '';

            if (type === 'worldmap') {
                tempUrl = 'templates/partials/modals/worldmap-partner-modal.html';
            }

            modal.open({

                templateUrl: tempUrl,
                windowTemplateUrl: 'templates/partials/modals/dashboard-modal-root.html',
                scope: scope,
                backdrop: false
            });
        };

        var deRegister = scope.$on('partnerMapData', function (event, partnerMapData) {

            for (var i = 0; i < partnerMapData.length; i ++) {

                (function (mapData) {

                    GeoService.zipGeoInfo(mapData.country, mapData.postalCode).then(function (gInfo) {

                        log.debug('GeoData:', gInfo);
                        mapData.lat = gInfo.lat;
                        mapData.lon = gInfo.lon;
                        delete scope.lcioMapOptions['map_data'];
                        var mapArr = partnerMapData.filter(function (obj) {
                             if (obj.lat && obj.lon) {
                                 return obj;
                             }
                        });
                        scope.lcioMapOptions['map_data'] = mapArr;
                    });
                })(partnerMapData[i]);
            }
        });

        scope.$on('$destroy', function () {
            deRegister();
        });

    }]);
})();
