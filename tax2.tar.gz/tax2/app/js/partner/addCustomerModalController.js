/* global angular */

(function () {
    'use strict';

    angular.module('lcio.partner')
    .controller('AddCustomerModalInstanceController', ['$scope', '$log', '$modalInstance', 'ResourceFactory', '$window',
    function (scope, log, modalInstance, ResourceFactory, window) {

        log.info('Controller === AddCustomerModalInstanceController');

        scope.custInfo = {
            'name': '',
            'email': '',
            'sendInvite': true
        };

        scope.ok = function () {

            ResourceFactory.Customer().createCustomer.save(scope.custInfo, function (data, responseHeaders) {

                scope.custList.unshift(data);

                if (!scope.custInfo.sendInvite) {
                    var resp = responseHeaders();
                    var newWindow = window.open(resp.location, 'name', 'height=300,width=650,screenX=650,screenY=350');
                    newWindow.onload = function () {
                        newWindow.document.title = 'Set Password';
                    };
                }

                modalInstance.close(true);
            });
        };

        scope.cancel = function () {
            modalInstance.dismiss('cancel');
        };

    }]);
})();
