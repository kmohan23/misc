/* global angular */
/* global _ */

(function () {
    'use strict';

    angular.module('lcio.partner')
        .controller('PartnerOpenDnsController', ['$scope', '$log', '$modal', '$stateParams', '$eventSock', 'LoginService',
            function (scope, log, modal, stateParams, eventSock, LoginService) {


                log.info('Controller === PartnerOpenDnsController');
            }]);

})();
