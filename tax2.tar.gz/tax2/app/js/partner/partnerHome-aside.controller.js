/* global angular */
/* global sessionStorage */
/* global L */
/*global _*/

(function () {
    'use strict';

    angular.module('lcio.partner')
        .controller('PartnerHomeAsideController', ['$scope', '$log', '$modal', 'LoginService', 'ResourceFactory', '$rootScope',
            function (scope, log, modal, LoginService, ResourceFactory, rootScope) {

                log.info('Controller === PartnerHomeAsideController');

                scope.roles = {
                    'isManage': true,
                    'isFulFill': true
                };

                var loginUser = { };
                LoginService.getLoginUser().then(function (luser) {
                    if (luser !== null) {
                        loginUser = luser;
                        scope.roles.isManage  = _.contains(loginUser['accessRoles'], 'PartnerAdmin');
                        scope.roles.isFulFill = _.contains(loginUser['accessRoles'], 'PartnerFulfillment');
                        scope.roles.isManage = true;
                        scope.roles.isFulFill = false;
                    }
                });

                scope.custList = [];

                function getPartnerMapArray(arr) {

                    return arr.filter(function (obj) {

                        if (obj.country && obj.postalCode) {
                           return obj;
                        }
                    });
                }

                ResourceFactory.Customer().listCustomers.query().$promise.then(function (data) {

                    scope.custList = data;
                    rootScope.$broadcast('partnerMapData', getPartnerMapArray(scope.custList));
                });

                scope.selectedCustomer = null;


                scope.selectCustomer = function (customer) {
                    scope.selectedCustomer = customer;
                };

                scope.zoomToCustomer = function (customer) {
                    if (customer.lat && customer.lon) {
                        rootScope.$broadcast('zoomToCustomer', {customer: customer});
                    }
                };

                scope.openAddCustomerModal = function () {

                    scope.addCustomerModalInstance = modal.open({

                        templateUrl: 'templates/partials/modals/addNewCustomer.html',
                        controller: 'AddCustomerModalInstanceController',
                        scope: scope,
                        backdrop: 'static',
                        keyboard: false
                    });

                    scope.addCustomerModalInstance.result.then(function () {
                        log.info('Printing customers List');
                        log.info(scope.custList);
                    }, function () {
                        log.info('Modal dismissed at: ' + new Date());
                    });
                };

                var licenses = [];

                rootScope.$on('CallFulfillMethod', function(event, data) {
                    scope.fulfillCustomer(data.id);
                });

                scope.fulfillCustomer = function (id) {

                    scope.fulfillModalInstance = modal.open({

                        templateUrl: 'templates/partials/modals/fulfill-customer.html',
                        controller: 'FulfillCustomerModalInstanceCtrl',
                        resolve: {
                            licenses: function () {
                                return licenses;
                            },
                            customerId: function () {
                                return id;
                            }
                        },
                        backdrop: 'static',
                        keyboard: false
                    });

                    scope.fulfillModalInstance.opened.then(function () {
                        ResourceFactory.GetLicense().query().$promise.then(function (data) {
                            scope.fulfillModalInstance.init(data);
                        });
                    }, function () {
                        log.info('Modal dismissed at: ' + new Date());
                    });
                };

                rootScope.$on('CallManageMethod', function(event, data) {
                    scope.manageCustomer(data.id, data.index);
                });

                scope.manageCustomer = function (id) {

                    scope.manageModalInstance = modal.open({
                        templateUrl: 'templates/partials/modals/customerProfile.html',
                        controller: 'CustomerProfileModalInstanceCtrl'
                    });

                    scope.manageModalInstance.opened.then(function () {
                        scope.loadCustomerProfileData(scope.manageModalInstance, id);
                    }, function () {
                        log.info('Modal dismissed at: ' + new Date());
                    });
                    scope.manageModalInstance.result.then(function (result) {
                        log.debug('Updated Customer:', result);
                        for(var i = 0; i < scope.custList.length; i++) {
                            if (scope.custList[i].id === result.id) {
                                scope.custList[i] = result;
                                break;
                            }
                        }
                        rootScope.$broadcast('partnerMapData', getPartnerMapArray(scope.custList));
                    }, function () {
                        log.info('Modal dismissed at: ' + new Date());
                    });
                };

                scope.loadCustomerProfileData = function (aModalInstance, id) {

                    log.info('load customer profile...');
                    ResourceFactory.CustomerProfile().get({custId: id}).$promise.then(function (data) {
                        data.id = id;
                        aModalInstance.setMyData(data);
                    }, function () {
                       log.info('Fetching customer Failed');
                    });
                };

            }]);
})();
