/* global angular */

(function () {
    'use strict';

    angular.module('lcio.partner')
    .controller('FulfillCustomerModalInstanceCtrl', ['$scope', '$modalInstance', 'licenses', '$timeout', 'customerId', 'ResourceFactory',
    function (scope, modalInstance, licenses, timeout, customerId, ResourceFactory) {

        scope.formErrorString = '';
        scope.custObj = {
            'approval': true,
            'requestApproval': true,
            'api': true,
            'swPci': true,
            'licenses': [],
            'license': {}
        };

        scope.custObj.licenses = licenses;

        modalInstance.init = function (licenses) {
            scope.custObj.licenses = licenses;
            scope.custObj.license = scope.custObj.licenses[0];
        };

        scope.ok = function () {

            var restObj = {

                entitlements: [],
                license: '',
                customer: {
                    id: ''
                }
            };

            if (scope.custObj.api) { restObj.entitlements.push('Api'); }
            if (scope.custObj.swPci) { restObj.entitlements.push('ScopewatchPci'); }
            restObj.license = scope.custObj.license.name;
            //restObj.customer.id = customerId;
            //console.log(restObj);

            ResourceFactory.PartnerFulfillment().save({id: customerId}, restObj, function () {
                modalInstance.close(true);
            });
        };

        scope.cancel = function () {
            modalInstance.dismiss('cancel');
        };

        scope.setWithTimeout = function (name, val) {

            scope[name] = val;
            timeout(function () {
                scope[name] = '';
            }, 5000);
        };

    }]);

})();

