/* global angular */
/* global L */
/* jshint loopfunc: true */
/* global $ */
/* global document */

(function () {
    'use strict';
    angular.module('lcio.partner')
    .directive('lcioPartnerMap', function () {
        return {
            scope: {
                mapData: '=mapData',
                fromModal: '@',
                mapTemplate: '=mapTemplate'
            },
            controller: ['$scope', '$element', '$attrs', '$log', '$compile', '$templateCache', '$rootScope',
                function ($scope, $element, $attrs, $log, $compile, templateCache, rootScope) {

                    this.map = null;
                    var remoteMarker = null;
                    this.markerGroup = null;
                    var currentMarker = null;

                    var blue = '#006DAA';
                    var lightBlue = '#7AA3B7';

                    this.markerArray = [];

                    if (!this.map) {

                        L.mapbox.accessToken = 'pk.eyJ1IjoicnRwZGV2b3BzIiwiYSI6ImNpZjVlbGxycDAybWVzYWt0Y3RxNWp6NTcifQ.5L87J-P0UJymWDuJGIw53Q';

                        if ($scope.fromModal === 'true') {
                            this.map = L.mapbox.map('mapModal', 'mapbox.light', {worldCopyJump:true, minZoom:2, maxZoom:13});
                        } else {
                            this.map = L.mapbox.map('map', 'mapbox.light', {worldCopyJump:true, minZoom:2, maxZoom:13});
                        }

                        //TODO: Center view on home marker, maybe get bounds of all markers?
                        this.map.setView([45, -119], 3);
                    }

                    var defaultMarkerIcon = L.mapbox.marker.icon({
                        'marker-color': lightBlue,
                        'marker-size': 'medium'
                    });

                    var highlightedMarkerIcon = L.mapbox.marker.icon({
                        'marker-color': blue,
                        'marker-size': 'medium'
                    });

                    this.redraw = function () {
                        $log.debug('lcioPartnerMap directive "redraw" called');

                        if (this.markerGroup === null) {
                            this.markerGroup = L.markerClusterGroup({
                                showCoverageOnHover: false,
                                iconCreateFunction: function (cluster) {
                                    return L.mapbox.marker.icon({
                                        'marker-symbol': cluster.getChildCount(),
                                        'marker-color': lightBlue,
                                        'marker-size': 'medium'
                                    });
                                }
                            });
                        } else {
                            this.markerGroup.clearLayers();
                        }

                        if (!!$scope.mapData && $scope.mapData.length > 0 && !!$scope.mapTemplate) {

                            var mapData = $scope.mapData;

                            this.markerArray = [];

                            for (var j = 0; j < mapData.length; j ++) {

                                var remotePoint = mapData[j];

                                if (remotePoint.lat && remotePoint.lon) {

                                    remoteMarker = new L.marker([remotePoint.lat, remotePoint.lon], {title: remotePoint.id, icon: defaultMarkerIcon});
                                    remoteMarker.popUpColor = '#7AA3B7';

                                    var templateScope = $scope.$new();
                                    templateScope.remotePoint = remotePoint;
                                    templateScope.remoteMarker = remoteMarker;
                                    var compiled = $compile($scope.mapTemplate)(templateScope);

                                    var customPopUp = L.popup({closeButton: false}).setContent(compiled[0]);
                                    remoteMarker.bindPopup(customPopUp);

                                    this.markerArray.push(remoteMarker);
                                    this.markerGroup.addLayer(remoteMarker);
                                }
                            }
                        }
                        this.map.addLayer(this.markerGroup);

                        //TODO: make this dynamic
                        $scope.setClusterSize = function (cluster) {
                            var childCount = cluster.getChildCount();
                            var clusterSize = 'small';
                            if(childCount > 5 && childCount <= 10) {
                                clusterSize = 'medium';
                            } else if(childCount > 10) {
                                clusterSize = 'large';
                            }
                            return clusterSize;
                        };

                        this.markerGroup.on('mouseover', function (e) {
                            if (!!currentMarker) {
                                currentMarker.setIcon(defaultMarkerIcon);
                            }
                            e.layer.openPopup();
                            e.layer.setIcon(highlightedMarkerIcon);
                            currentMarker = e.layer;
                        });

                        this.markerGroup.on('mouseout', function (e) {
                            e.layer.setIcon(defaultMarkerIcon);
                        });

                        this.markerGroup.on('clustermouseover', function (e) {
                            if (!!currentMarker) {
                                currentMarker.closePopup();
                            }
                            e.layer.setIcon(L.mapbox.marker.icon({
                                'marker-symbol': e.layer.getChildCount(),
                                'marker-color': blue,
                                'marker-size': 'medium'
                            }));
                        });

                        this.markerGroup.on('clustermouseout', function (e) {
                            e.layer.setIcon(L.mapbox.marker.icon({
                                'marker-symbol': e.layer.getChildCount(),
                                'marker-color': lightBlue,
                                'marker-size': 'medium'
                            }));
                        });

                    };

                    $scope.closePopUp = function (marker) {
                        marker.closePopup();
                    };

                    $scope.manageCustomer = function(data) {
                        rootScope.$emit('CallManageMethod', {id: data.id});
                    };

                    $scope.fulfillCustomer = function(data) {
                        rootScope.$emit('CallFulfillMethod', {id: data.id});
                    };
                }],

            link: function (scope, el, attrs, ctrl) {

                console.debug('lcioPartnerMap directive "link" called');
                scope.$watchCollection('mapData', function (newVal) {
                    if (!!newVal) {
                        ctrl.redraw();
                    }
                });

                var locationDeRegister = scope.$on('partnerLocation', function (event, obj) {
                    var homeMarker = new L.marker([obj.lat, obj.lon], {title: obj.id, icon: L.mapbox.marker.icon({'marker-symbol': 'building'})});
                    ctrl.map.addLayer(homeMarker);
                });

                var deRegister = scope.$on('zoomToCustomer', function (event, obj) {
                    var mapZoomArr = ctrl.markerArray.filter(function (mapObj) {
                        if (mapObj.options.title === obj.customer.id) {
                         return mapObj;
                        }
                    });
                    var custMarker = mapZoomArr[0];

                    ctrl.markerGroup.zoomToShowLayer(custMarker, function () {
                            custMarker.fireEvent('mouseover');
                    });
                });

                scope.$on('$destroy', function () {
                    deRegister();
                    locationDeRegister();
                });
            }
        };
    });
})();
