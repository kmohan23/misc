/* global angular */

(function () {
    'use strict';
    angular.module('lcio.login')
    .service('LoginUserService', ['LoginService', '$stateParams', '$modal', '$q', '$log',
    function (LoginService, stateParams, modal, q, log) {
        this.getCurrentTenant = function () {
            var deferred = q.defer();
            LoginService.getLoginUser().then(function (loginUser) {
                if (loginUser === null) {
                    log.error('Failed to get LoginUser, cannot set active tenantId');
                    deferred.reject('cannot determine current user');
                } else {
                    var idx = stateParams.activeTenantIndex;
                    log.debug('active tenant index = ' + idx);
                    if (idx < loginUser.tenants.length) {
                        var activeTenant = loginUser.tenants[idx];
                        log.debug('active tenant = ' + activeTenant['id']);
                        deferred.resolve(activeTenant);
                    } else {
                        log.debug('no active tenant (index out of range)');
                        deferred.reject('cannot determine active tenant');
                    }
                }
            });
            log.debug('asking for LoginUser... waiting...');
            return deferred.promise;
        };
    }]);
})();

