/* global angular */

(function () {
    'use strict';

    angular.module('lcio.login')
    .service('LoginService', ['$rootScope', '$modal', '$q', '$log', '$eventSock', 'ResourceFactory',
    function (rootScope, modal, q, log, eventSock, ResourceFactory) {
        var _loginUser = null;
        this.getLoginUser = function () {
            var deferred = q.defer();
            this.checkLogin().then(function (loggedIn) {
                if (loggedIn === true) {
                    deferred.resolve(_loginUser);
                } else {
                    deferred.resolve(null);
                }
            });
            return deferred.promise;
        };

        var _lastError = null;
        //this.getLastError = function () {
        //    return _lastError;
        //};

        var _loginSuccess = function (data) {
            _loginUser = data;
            if (!rootScope.globals.hasOwnProperty('loggedIn') || rootScope.globals.loggedIn !== true) {
                rootScope.globals.loggedIn = true;
                log.debug('User logged in (' + _loginUser.username + ')', _loginUser);
            }
            if (!eventSock.isConnected()) {
                eventSock.start().then(function () {
                    log.debug('Event Sock started...');
                });
            }
        };

        function EulaChecker(modal, resFactory, q, log) {
            var _eulaDisplay = function (data) {
                var deferred = q.defer();
                var lModal = modal.open(
                    {
                        templateUrl: '../../templates/login/eulaDialog.html',
                        controller: 'EulaController',
                        size: 'lg',
                        backdrop: 'static',
                        keyboard: false,
                        resolve: {
                            text: function () {
                                return data;
                            }
                        }
                    });

                lModal.result.then(function (eulaResponse) {
                    log.debug('EULA result, ', eulaResponse);
                    if (eulaResponse !== true) {
                        deferred.resolve(false);
                    } else {
                        resFactory.Activate().get().$promise.then(function (data) {
                            if (data.status === 200) {
                                resFactory.Activate({'token': data.message}).update().$promise.then(function (data) {
                                    if (data.status === 200) {
                                        deferred.resolve(true);
                                    }
                                });
                            }
                        });
                    }
                });
                return deferred.promise;
            };
            this.checkEula = function () {
                var deferred = q.defer();
                try {
                    resFactory.Eula().get().$promise.then(function (data) {
                        try {
                            if (200 !== data.status) {
                                // Most likely here as a result of 204
                                deferred.resolve(true);
                            } else {
                                _eulaDisplay(data.message).then(function (accept) {
                                    deferred.resolve(accept);
                                });
                            }
                        } catch (err) {
                            log.debug('ERROR: ', err);
                            deferred.resolve(false);
                        }
                    });
                } catch (err) {
                    log.debug('CATCH: ', err);
                    deferred.resolve(false);
                }
                return deferred.promise;
            };
        }

        var _checkEula = function () {
            var deferred = q.defer();
            new EulaChecker(modal, ResourceFactory, q, log).checkEula().then(function (accept) {
                deferred.resolve(accept);
            });
            return deferred.promise;
        };
        this.checkEula = function () {
            return _checkEula();
        };

        // Need local logout function to be called from EULA promise callback
        var _logout = function () {
            var deferred = q.defer();
            ResourceFactory.Login().remove().$promise.then(function () {
                try {
                    _loginUser = null;
                    rootScope.globals.loggedIn = false;
                    deferred.resolve(true);
                }
                catch (err) {
                    _lastError = err;
                    deferred.resolve(false);
                }
            });
            return deferred.promise;
        };
        // And a logout method for service
        this.logout = function () {
            return _logout();
        };

        this.login = function (email, pass) {
            var deferred = q.defer();
            if (_loginUser !== null) {
                deferred.resolve(_loginUser);
            } else {
                ResourceFactory.Login().save({username: email, password: pass}).$promise.then(
                    function (data) {
                        _loginSuccess(data);
                        deferred.resolve(data);
                    },
                    function (resp) {
                        log.debug('Login failed: ', resp.data);
                        _lastError = resp.data;
                        deferred.resolve(null);
                    });
            }
            return deferred.promise;
        };

        this.checkLogin = function () {
            var deferred = q.defer();
            if (_loginUser !== null) {
                deferred.resolve(true);
            } else {
                ResourceFactory.Session().get().$promise.then(
                    function (data) {
                        //log.debug('Got Session:', data.username);
                        _loginSuccess(data);
                        deferred.resolve(true);
                    }, function (resp) {
                        log.debug('Could not get session, status: ', resp.status);
                        deferred.resolve(false);
                    });
            }
            return deferred.promise;
        };
    }])

    .controller('EulaController', ['$scope', 'text',
    function (scope, text) {
        scope.eulaText = text;
    }]);
})();

