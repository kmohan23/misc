/* global angular */

(function () {
    'use strict';

    angular.module('lcio.login')
    .controller('LoginController', ['$state', '$scope', '$window', '$timeout', '$log', '$modal', 'LoginService', 'ResourceFactory',
    function (state, scope, window, timeout, log, modal, LoginService, ResourceFactory) {

        log.debug('Controller ===  Login');
        log.debug(' State: ', state);
        log.debug('Params: ', state.params);
        log.debug('Scope', scope);


        scope.formErrorString = '';
        scope.duplicateError = false;
        scope.expiredInvalid = false;
        scope.requestSuccess = false;

        scope.btnStatus = {
            'loginDisabled': true,
            'spiceWorksDisabled': true
        };

        ResourceFactory.Features().list().$promise.then(function (data) {
            log.debug('Settings', data);
            scope.btnStatus.loginDisabled = !data['enableLogin'];
            scope.btnStatus.spiceWorksDisabled = !data['enableSpiceWorks'];
        }, function (resp) {
            log.debug('Settings Resp', resp);
        });

        LoginService.checkLogin().then(function (loggedIn) {
            if (loggedIn === true) {
                scope.loginSuccess();
            }
        });

        if (state.is('login.verify')) {
            scope.verifyToken = null;
            ResourceFactory.Verify({id: state.params.id}).get({t: state.params.t},
                function (data) {
                    try {
                        if (data.status === 200) {
                            scope.verifyToken = data.message;
                        } else {
                            scope.expiredInvalid = true;
                        }
                    }
                    catch (err) {
                        scope.setWithTimeout('formErrorString', err);
                    }
                },
                function (resp) {
                    try {
                        if (resp.status === 410) {  // gone
                            scope.expiredInvalid = true;
                        } else {
                            scope.setWithTimeout('formErrorString', resp.data);
                        }
                    }
                    catch (err) {
                        scope.setWithTimeout('formErrorString', err);
                    }
                }
            );
        } else if (state.is('login.reset')) {
            scope.pwResetToken2 = null;
            ResourceFactory.PassReset({id: state.params.id}).get({t: state.params.t},
                function (data) {
                    try {
                        if (data.status === 200) {
                            scope.pwResetToken2 = data.message;
                        } else {
                            scope.expiredInvalid = true;
                        }
                    }
                    catch (err) {
                        scope.setWithTimeout('formErrorString', err);
                    }
                },
                function (resp) {
                    try {
                        if (resp.status === 410) {  // gone
                            scope.expiredInvalid = true;
                        } else {
                            scope.setWithTimeout('formErrorString', resp.data);
                        }
                    }
                    catch (err) {
                        scope.setWithTimeout('formErrorString', err);
                    }
                }
            );
        }

        scope.loginSuccess = function () {
            LoginService.checkEula().then(function (accept) {
                if (accept !== true) {
                    LoginService.logout().then(function () {
                        log.debug('User did not accept EULA, logged out.');
                    });
                } else if (state.params.toState) {
                    state.go(state.params.toState, state.params.toParams);
                } else {
                    window.location('/');
                }
            });
        };

        scope.userLogin = function (emailAddress, password) {
            LoginService.login(emailAddress, password).then(function (data) {
                if (data === null) {
                    scope.setWithTimeout('formErrorString', 'The email and password you entered do not match.');
                } else {
                    scope.loginSuccess();
                }
            });
        };

        scope.submitFormVerifyReset = function (password) {
            if (state.is('login.verify')) {
                scope.verifyReg(password);
            } else if (state.is('login.reset')) {
                scope.verifyPasswordReset(password);
            }
        };

        scope.submitFormRegisterPassforgot = function (email) {
            if (state.is('login.register')) {
                scope.userRegister(email);
            } else if (state.is('login.passforgot')) {
                scope.forgotPassword(email);
            }
        };

        /* NEW ACCOUNT REGISTRATION - STEP 1 */
        scope.userRegister = function (emailAddress) {
            ResourceFactory.Registration().save({email: emailAddress},
                function (data) {
                    try {
                        if (data.status === 201 || data.status === 204) {
                            scope.setWithTimeout('requestSuccess', data.message);
                        } else {
                            scope.setWithTimeout('formErrorString', data.message);
                        }
                    }
                    catch (err) {
                        scope.setWithTimeout('formErrorString', err);
                    }
                },
                function (resp) {
                    try {
                        if (resp.status === 400) {
                            // 400/BAD_REQUEST if something (like email address) is not acceptable
                            scope.setWithTimeout('formErrorString', resp.data.message);
                        } else if (resp.status === 409) {
                            // 409/CONFLICT for re-registering an existing user
                            scope.duplicateError = true;
                        } else {
                            scope.setWithTimeout('formErrorString', resp.data);
                        }
                    }
                    catch (err) {
                        scope.setWithTimeout('formErrorString', err);
                    }
                }
            );
        };


        /* NEW ACCOUNT REGISTRATION - STEP 3 */
        scope.verifyReg = function (password) {
            ResourceFactory.Verify({id: state.params.id}).save({
                    email: scope.verifyToken,
                    password: password
                },
                function (data) {
                    try {
                        if (data.status === 201) {
                            scope.passwordSaved = true;
                            state.go('^.login');
                        } else {
                            scope.setWithTimeout('formErrorString', data.message);
                        }
                    }
                    catch (err) {
                        scope.setWithTimeout('formErrorString', err);
                    }
                },
                function (resp) {
                    try {
                        if (resp.status === 410) {  // gone
                            scope.expiredInvalid = true;
                        } else {
                            scope.setWithTimeout('formErrorString', resp.data);
                        }
                    }
                    catch (err) {
                        scope.setWithTimeout('formErrorString', err);
                    }
                }
            );
        };

        /* FORGOT PASSWORD - STEP 1 */
        scope.forgotPassword = function (emailAddress) {

            scope.btnStatus.resetBtnDisabled = true;
            ResourceFactory.PassForgot().save({email: emailAddress},
                function (data) {
                    try {
                        if (data.status === 201) {
                            // 201 is success
                            scope.openInfoModal();
                        } else {
                            scope.openInfoModal();
                        }
                    }
                    catch (err) {
                        scope.openInfoModal();
                    }
                    scope.btnStatus.resetBtnDisabled = false;
                },
                function (resp) {
                    try {
                        if (resp.status === 409) {
                            // 409 means user has already tried to reset his password
                            scope.duplicateError = true;
                        } else {
                            scope.openInfoModal();
                        }
                    }
                    catch (err) {
                        scope.openInfoModal();
                    }
                    scope.btnStatus.resetBtnDisabled = false;
                }
            );
        };

        /* FORGOT PASSWORD - STEP 3 */
        scope.verifyPasswordReset = function (password) {
            ResourceFactory.PassReset({id: state.params.id}).save({
                    email: scope.pwResetToken2,
                    password: password
                },
                function (data) {
                    try {
                        scope.passwordSaved = true;
                        state.go('^.login');
                    }
                    catch (err) {
                        scope.setWithTimeout('formErrorString', data.message);
                    }
                },
                function (resp) {
                    try {
                        if (resp.status === 410) {  // gone
                            scope.expiredInvalid = true;
                        } else {
                            scope.setWithTimeout('formErrorString', resp.data);
                        }
                    }
                    catch (err) {
                        scope.setWithTimeout('formErrorString', err);
                    }
                }
            );
        };

        scope.setWithTimeout = function (name, val) {
            scope[name] = val;
            timeout(function () {
                scope[name] = '';
            }, 10000);
        };

        scope.openInfoModal = function () {

            var modalInstance = modal.open({

                templateUrl: 'templates/partials/modals/password-reset.html',
                size: 'sm',
                backdrop: false
            });

            modalInstance.result.then(function () {
                state.go('login.login', state.params);
            }, function () {
                state.go('login.login', state.params);
            });
        };
    }]);
})();
