/* global angular */

(function () {
    'use strict';

    angular.module('lcio.login')
    .controller('LoginHeaderController', ['$scope', '$log', 'ResourceFactory', function (scope, log, ResourceFactory) {
        log.debug('Controller ===  LoginHeaderController');

        scope.btnStatus = {
            'registrationDisabled': true
        };

        ResourceFactory.Features().list().$promise.then(function (data) {
            scope.btnStatus.registrationDisabled = !data.enableRegistration;
        }, function (resp) {
        });
    }]);
})();
