/* global angular */
/* global _ */

(function () {
    'use strict';

    angular.module('lcio')
    .controller('ScreenHeaderCtrl', ['$scope', '$state', '$eventSock', '$modal', '$log', 'ResourceFactory', 'LoginService',
    function (scope, state, eventSock, modal, log, ResourceFactory, LoginService) {
        log.debug('Controller ===  ScreenHeaderCtrl');

        scope.visibilityObj = {
            'api': false,
            'swPci': false,
            'bulkPartner': false,
            'dashboardState': 'user-dash',
            'showCustomerProfile': true,
            'showPartnerProfile': true
        };
        scope.loginUser = { };

        LoginService.getLoginUser().then(function (luser) {
            if (luser === null) { return; }

            scope.loginUser = luser;
            scope.visibilityObj.showCustomerProfile = _.contains(scope.loginUser.accessRoles, 'CustomerAdmin');
            scope.visibilityObj.showPartnerProfile  = _.contains(scope.loginUser.accessRoles, 'PartnerAdmin');

            if (state.is('screen.partnerhome') || state.is('screen.partnerdetail')) {
                scope.visibilityObj.dashboardState = 'partner-dash';
            } else {
                scope.visibilityObj.dashboardState = 'user-dash';
            }

            if ((scope.visibilityObj.dashboardState === 'user-dash') && scope.loginUser.tenants && scope.loginUser.tenants.length > 0) {
                scope.setAccessibilityAndRedirect(0, false);
            }

            if (state.is('screen.home')) {
                log.info('state = screen.home : checking user type');

                var isPartnerUser =
                    _.contains(scope.loginUser.accessRoles, 'PartnerAdmin') ||
                    _.contains(scope.loginUser.accessRoles, 'PartnerFulfillment') ||
                    _.contains(scope.loginUser.accessRoles, 'PartnerAccess');

                if (isPartnerUser) {
                    log.info('PARTNER ADMIN/FULFILLMENT user is logged in, send to partner home.');
                    state.params.toState = 'screen.partnerhome';
                    scope.visibilityObj.dashboardState = 'partner-dash';
                    // TODO: This is currently hardcoded to true, need to add the logic to check for whether or not the entitlement exists
                    scope.visibilityObj.openDNSMSP = true;

                } else {
                    state.params.toState = 'screen.tw.home';
                    scope.visibilityObj.dashboardState = 'user-dash';
                }
                state.go(state.params.toState, state.params.toParams);
            }
        });

        scope.logout = function () {
            try {
                eventSock.stop();
            }
            catch (err) {
                log.error(err);
            }
            LoginService.logout().then(function () {
                state.go('login.login');
            });
        };

        scope.setAccessibilityAndRedirect = function (index, redirect) {

            if (scope.loginUser.tenants[index].entitlements && scope.loginUser.tenants[index].entitlements.length > 0) {
                scope.visibilityObj.api = scope.loginUser.tenants[index].entitlements.indexOf('Api') === -1;
                scope.visibilityObj.swPci = scope.loginUser.tenants[index].entitlements.indexOf('ScopewatchPci') === -1;
                scope.visibilityObj.openDNS = scope.loginUser.tenants[index].entitlements.indexOf('OpenDNS') === -1;
                scope.visibilityObj.cogThreatAnalytics = scope.loginUser.tenants[index].entitlements.indexOf('CognitiveThreatAnalytics') === -1;
                scope.visibilityObj.investigativeService = scope.loginUser.tenants[index].entitlements.indexOf('InvestigativeService') === -1;
            } else {
                scope.visibilityObj.api = true;
                scope.visibilityObj.swPci = true;
                scope.visibilityObj.openDNS = true;
                scope.visibilityObj.cogThreatAnalytics = true;
                scope.visibilityObj.investigativeService = true;
            }

            if (redirect) {
                state.go('screen.dashboard', {'activeTenantIndex': index});
            }
        };

        scope.showUserProfile = function () {

            var modalInstance = modal.open({

                templateUrl: 'templates/partials/modals/userProfile.html',
                controller: 'UserProfileModalInstanceCtrl',
                resolve: {
                    fromType: function () {
                        return 'from-screen-header';
                    }
                },
                backdrop: 'static',
                keyboard: false
            });

            modalInstance.opened.then(function () {
                scope.loadUserProfileData(modalInstance);
            }, function () {
                log.info('Modal dismissed at: ' + new Date());
            });
        };

        scope.loadUserProfileData = function (aModalInstance) {
            log.info('load user profile...');
            ResourceFactory.UserProfile().get().$promise.then(function (data) {
                log.debug(data);
                aModalInstance.setMyData(data);
            });
        };

        scope.showPartnerProfile = function () {
            var modalInstance = modal.open({
                templateUrl: 'templates/partials/modals/partnerProfile.html',
                controller: 'PartnerProfileModalInstanceCtrl',
                backdrop: 'static',
                keyboard: false
            });

            modalInstance.opened.then(function () {
                scope.loadPartnerProfileData(modalInstance);
            }, function () {
                log.info('Modal dismissed at: ' + new Date());
            });
        };

        scope.loadPartnerProfileData = function (aModalInstance) {
            log.info('load partner profile...');
            ResourceFactory.PartnerProfile().get().$promise.then(function (data) {
                log.debug(data);
                aModalInstance.setMyData(data);
            });
        };

        scope.showCustomerProfile = function () {

            var modalInstance = modal.open({
                templateUrl: 'templates/partials/modals/customerProfile.html',
                controller: 'CustomerProfileModalInstanceCtrl',
                backdrop: 'static',
                keyboard: false
            });

            modalInstance.opened.then(function () {
                scope.loadCustomerProfileData(modalInstance);
            }, function () {
                log.info('Modal dismissed at: ' + new Date());
            });
        };

        scope.loadCustomerProfileData = function (aModalInstance) {
            log.info('load customer profile...');
            ResourceFactory.CustomerProfile().get().$promise.then(function (data) {
                log.debug(data);
                aModalInstance.setMyData(data);
            });
        };

        var licenses = [];

        scope.upgradeAppliance = function (fromType) {

            var modalInstance = modal.open({

                templateUrl: 'templates/partials/modals/upgrade-license.html',
                controller: 'UpgradeModalInstanceCtrl',
                resolve: {
                    licenses: function () {
                        return licenses;
                    },
                    fromType: function () {
                        return fromType;
                    }
                }
            });

            modalInstance.opened.then(function () {
                ResourceFactory.GetLicense().query().$promise.then(function (data) {
                    modalInstance.init(data);
                });
            }, function () {
                log.info('Modal dismissed at: ' + new Date());
            });
        };

        scope.openHelpModal = function () {

            modal.open({
                templateUrl: 'templates/partials/modals/help.html',
                controller: 'HelpModalInstanceCtrl',
                size: 'md',
                backdrop: 'static',
                keyboard: false
            });
        };
    }
    ]);
})();

