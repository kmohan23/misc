/* global angular */

(function () {
    'use strict';

    angular.module('lcio')
    .controller('CustomerProfileModalInstanceCtrl', ['$scope', '$modalInstance', '$timeout', 'ResourceFactory',
    function (scope, modalInstance, timeout, ResourceFactory) {

        console.log('CustomerProfileModalInstanceCtrl');

        scope.customerInfo = {};
        scope.formErrorString = '';

        modalInstance.setMyData = function (uinfo) {
            scope.customerInfo = uinfo;
        };

        scope.ok = function () {

            var restObj = angular.copy(scope.customerInfo);

            ResourceFactory.CustomerProfile().update({custId: scope.customerInfo.id}, restObj).$promise.then(function (data) {
                modalInstance.close(data);
            }, function () {
                modalInstance.dismiss('failed');
                scope.setWithTimeout('formErrorString', 'Save Failed');
            });
        };

        scope.cancel = function () {
            modalInstance.dismiss('cancel');
        };

        scope.setWithTimeout = function (name, val) {
            scope[name] = val;
            timeout(function () {
                scope[name] = '';
            }, 5000);
        };

    }]);
})();

