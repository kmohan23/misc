/* global angular */

(function () {
    'use strict';

    angular.module('lcio')
    .controller('UnAuthorizedModalInstanceCtrl', ['$scope', 'errMsg',
    function (scope, errMsg) {
        scope.errMsg = errMsg;
    }]);
})();

