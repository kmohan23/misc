/* global angular */

(function () {
    'use strict';

    angular.module('lcio')
    .controller('UpgradeModalInstanceCtrl', ['$scope', '$modalInstance', '$timeout', 'licenses', 'fromType', '$stateParams', 'ResourceFactory', 'LoginService',
    function (scope, modalInstance, timeout, licenses, fromType, stateParams, ResourceFactory, LoginService) {

        scope.formErrorString = '';
        scope.tenants = [];

        // Initialization Stuff Starts
        var loginUser = {};

        function setLicense(tenant, license) {

            console.log('Printing setLicense Tenant Size');
            console.log(scope.tenants.length);

            var actualLicense;

            if (!tenant.license) {
                actualLicense = license[0];
                return actualLicense;
            }

            for (var i = 0; i < license.length; i++) {
                if (tenant.license.size === license[i].size) {
                    actualLicense = license[i];
                    break;
                }
            }

            return actualLicense;
        }
        function hasEntitlements(val, arr) {

            if (arr) {
                for (var i = 0; i < arr.length; i ++) {
                    if (val === arr[i]) {
                        return true;
                    }
                }
            }
            return false;
        }

        modalInstance.init = function (license) {

            LoginService.getLoginUser().then(function (loginUser) {

                if (fromType === 'api' || fromType === 'swpci' || fromType === 'opendns' || fromType === 'cta' || fromType === 'investigativeservice' || fromType === 'opendnsmsp') {

                    scope.tenants.push(loginUser.tenants[stateParams.activeTenantIndex]);
                    scope.tenants[0].showText = false;
                    scope.tenants[0].licenseArr = license;
                    scope.tenants[0].license = setLicense(scope.tenants[0], license);

                    if (fromType === 'api') {
                        scope.tenants[0].api = true;
                    }

                    if (fromType === 'swpci') {
                        scope.tenants[0].swPci = true;
                    }

                    if (fromType === 'opendns') {
                        scope.tenants[0].openDNS = true;
                    }

                    if (fromType === 'cta') {
                        scope.tenants[0].cogThreatAnalytics = true;
                    }

                    if (fromType === 'investigativeservice') {
                        scope.tenants[0].investigativeService = true;
                    }

                    if (fromType === 'opendnsmsp') {
                        scope.tenants[0].openDNSMSP = true;
                    }
                } else {

                    scope.tenants = angular.copy(loginUser.tenants);
                    angular.forEach(scope.tenants, function (tenant) {

                        tenant.showText = false;
                        tenant.api = hasEntitlements('Api', tenant.entitlements);
                        tenant.swPci = hasEntitlements('ScopewatchPci', tenant.entitlements);
                        tenant.licenseArr = license;
                        tenant.license = setLicense(tenant, license);
                        tenant.entitlements = (tenant.entitlements) ? tenant.entitlements : [];
                    });

                    scope.tenants.push({'tenantName': '', 'showText': true, 'api': false, 'swPci': false, 'licenseArr': license, 'license': null, 'entitlements': []});
                }

            });

        };

        // Initialization Stuff Ends

        scope.ok = function () {

            // Go through submitted form info, and fill in an object to be sent to the REST server.

            var restObj = [];
            angular.forEach(scope.tenants, function (formInfo) {

                // No license level chosen from the pull-down, so just eliminate it.
                if (formInfo.license === null) {
                    return;
                }

                var restTenant = {};

                // Existing tenants have IDs, new ones do not.
                if (formInfo.hasOwnProperty('id')) {
                    restTenant.id = formInfo.id;
                }

                // No name given, so create a default name.
                if (formInfo.tenantName === '') {
                    restTenant.tenantName = '[NO NAME]';
                } else {
                    restTenant.tenantName = formInfo.tenantName;
                }

                restTenant.entitlements = [];
                if (formInfo.api) {
                    restTenant.entitlements.push('Api');
                }
                if (formInfo.swPci) {
                    restTenant.entitlements.push('ScopewatchPci');
                }

                // The tenant was sent to us as an object with a name and a size.
                // But it expects us to set the license level by name only.
                // So just send the name to the web back end, and forget the LicenseLevel object.
                restTenant.license = formInfo.license.name;

                restObj.push(restTenant);
            });

            ResourceFactory.Help().emailSalesHelp(restObj,
                function ()  {
                    modalInstance.dismiss('cancel');
                },
                function (resp) {}
            );
        };

        scope.cancel = function () {
            modalInstance.dismiss('cancel');
        };

        scope.setWithTimeout = function (name, val) {

            scope[name] = val;
            timeout(function () {
                scope[name] = '';
            }, 5000);
        };

    }]);

})();

