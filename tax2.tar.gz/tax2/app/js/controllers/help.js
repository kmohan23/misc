/* global angular */

(function () {
    'use strict';

    angular.module('lcio')
    .controller('HelpModalInstanceCtrl', ['$scope', '$modalInstance', '$timeout', 'ResourceFactory', 'LoginUserService', '$stateParams', '$log',
    function (scope, modalInstance, timeout, ResourceFactory, LoginUserService, stateParams, log) {

        scope.formErrorString = '';
        scope.helpObj = {
            severityLevels: ['High', 'Medium', 'Low'],
            severity: 'High',
            subjectList: [
                'I am unable to download the appliance...',
                'I am unable to install the appliance...',
                'I am not able to configure my network to send data to the appliance...',
                'My appliance is not receiving netflow...',
                'My appliance is not connecting to the service...',
                'I do not see any data...',
                'I would like to report a bug or request a new feature...',
                'Other...'
            ],
            subject: 'Other...',
            description: ''
        };

        scope.ok = function () {
            scope.formErrorString = '';
            LoginUserService.getCurrentTenant().then(
                function (tenant) {
                    scope.sendHelpEmail(tenant['id']);
                },
                function (reason) {
                    log.error('error looking up tenant: ' + reason);
                    scope.sendHelpEmail('');
                }
            );
        };
        scope.sendHelpEmail = function (activeTenantId) {
            ResourceFactory.Help().emailHelp({
                    severity: scope.helpObj.severity,
                    subject: scope.helpObj.subject,
                    description: scope.helpObj.description,
                    tenant: activeTenantId
                },
                function ()  {
                    modalInstance.dismiss('cancel');
                },
                function (resp) {
                    scope.formErrorString = 'response ' + resp.status + ' from server';
                }
            );
        };

        scope.cancel = function () {
            modalInstance.dismiss('cancel');
        };

        scope.setWithTimeout = function (name, val) {

            scope[name] = val;
            timeout(function () {
                scope[name] = '';
            }, 5000);
        };

    }]);
})();

