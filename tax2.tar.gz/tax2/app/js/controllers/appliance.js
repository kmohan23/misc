/* global angular */

(function () {
    'use strict';

    angular.module('lcio')
    .controller('ApplianceController', ['$scope', '$interval', '$log', 'isEdit', 'ResourceFactory', 'ApplianceDownloadFactory',
    function (scope, interval, log, isEdit, ResourceFactory, ApplianceDownloadFactory) {

        log.debug('Controller ===  ApplianceCtrl');

        scope.gridOptions = {
            data: '',
            excessRows: 0,
            excessColumns: 0,
            scrollThreshold: 0,
            enableCellSelection: false,
            enableRowSelection: false,
            enableCellEdit: true,
            enableCellEditOnFocus: true,
            enableColumnMenus: false,
            rowEditWaitInterval: -1,
            expandableRowTemplate: 'templates/partials/appliance/instanceGrid.html',
//                expandableRowHeight: 80,
            expandableRowScope: {
                subGridOptions: '=subGridOptions'
            },
            columnDefs: [
                {field: 'id', visible: false},
                {field: 'applianceName', displayName: 'Name', width: '***', enableCellEdit: true},
                {field: 'address', displayName: 'Address', width: '***', enableCellEdit: true},
                {
                    name: 'toolbar', displayName: 'Actions...', width: '*', enableCellEdit: false, enableSorting: false,
                    cellTemplate: 'templates/partials/appliance/applianceButtons.html'
                }
            ]
        };

        var stopInterval;

        ResourceFactory.Appliance().query().$promise.then(function (data) {

            scope.gridOptions.data = data;
            //log.info('GridOptions Data');
            //log.info(scope.gridOptions);

            if (isEdit) {
                stopInterval = interval(function () {

                    var rows = scope.gridApi.grid.rows;
                    if (rows.length) {
                        scope.stopInterval();
                    }
                    setTimeout(function () {
                        scope.gridApi.expandable.expandAllRows();
                    }, 300);
                }, 100);
            }
        });

        scope.stopInterval = function () {

            if (angular.isDefined(stopInterval)) {

                interval.cancel(stopInterval);
                stopInterval = undefined;
            }
        };

        scope.saveRow = function (rowEntity) {
            var newAppl;
            delete rowEntity.subGridOptions;
            log.debug('Save Row', rowEntity);
            if (rowEntity.hasOwnProperty('id') && rowEntity.id) {
                newAppl = ResourceFactory.Appliance().update(rowEntity, rowEntity).$promise.then(function (data) {
                    var gridData = scope.gridApi.grid.options.data;
                    gridData[gridData.indexOf(rowEntity)] = data;
                });
            } else {
                newAppl = ResourceFactory.Appliance().save(rowEntity).$promise.then(function (data) {
                    var gridData = scope.gridApi.grid.options.data;
                    gridData[gridData.indexOf(rowEntity)] = data;
                });
            }
            scope.gridApi.rowEdit.setSavePromise(rowEntity, newAppl);
        };
        scope.saveInstanceRow = function (rowEntity) {
            var newInst;
            delete rowEntity.subGridOptions;
            log.debug('Save Instance', rowEntity);
            if (rowEntity.hasOwnProperty('id') && rowEntity.id) {
                newInst = ResourceFactory.ApplianceInstance().update(rowEntity, rowEntity).$promise.then(function (data) {
                    var gridData = scope.subGridApi.grid.options.data;
                    gridData[gridData.indexOf(rowEntity)] = data;
                });
            } else {
                newInst = ResourceFactory.ApplianceInstance().save(rowEntity).$promise.then(function (data) {
                    var gridData = scope.subGridApi.grid.options.data;
                    gridData[gridData.indexOf(rowEntity)] = data;
                });
            }
            scope.subGridApi.rowEdit.setSavePromise(rowEntity, newInst);
        };

        scope.gridApi = null;
        scope.subGridApi = null;
        scope.gridOptions.onRegisterApi = function (gridApi) {
            scope.gridApi = gridApi;
            //log.info('Printing gridApi');
            //log.info(gridApi);

            scope.gridApi.rowEdit.on.saveRow(scope, scope.saveRow);
            scope.gridApi.expandable.on.rowExpandedStateChanged(scope, function (row) {
                if (row.isExpanded) {
                    row.entity.subGridOptions = {
                        appScopeProvider: scope,
                        excessRows: 0,
                        excessColumns: 0,
                        scrollThreshold: 0,
                        enableCellSelection: false,
                        enableRowSelection: false,
                        enableCellEdit: true,
                        enableCellEditOnFocus: true,
                        enableColumnMenus: false,
                        rowEditWaitInterval: -1,
                        columnDefs: [
                            {field: 'id', visible: false},
                            {field: 'instanceName', displayName: 'Instance Name', width: '**', enableCellEdit: true},
                            {field: 'activationKey', displayName: 'Activation Key', width: '**', enableCellEdit: true},
                            {field: 'status', displayName: 'Status', width: '*', enableCellEdit: false},
                            {
                                field: 'activated', displayName: 'Activated', width: '*', enableCellEdit: false,
                                cellTemplate: '<span><i class="fa fa-check fa-lg fa-fw" data-ng-show="row.entity.activated"></i><span>'
                            },
                            {
                                name: 'toolbar', width: '*', enableCellEdit: false, enableSorting: false,
                                headerCellTemplate: 'templates/partials/appliance/applianceInstanceActionHeader.html',
                                cellTemplate: 'templates/partials/appliance/applianceInstanceButtons.html'
                            }
                        ]
                    };
                    row.entity.subGridOptions.data = ResourceFactory.Appliance().instances({'id': row.entity.id});
                    row.entity.subGridOptions.applianceId = row.entity.id;
                    row.entity.subGridOptions.onRegisterApi = function (subGridApi) {
                        scope.subGridApi = subGridApi;
                        scope.subGridApi.rowEdit.on.saveRow(scope, scope.saveInstanceRow);
                    };
                }
            });
        };

        scope.actionHandler = {
            onSave: function (event, row) {
                event.stopPropagation();
                row.grid.api.rowEdit.raise.saveRow(row.entity);
            },
            onUndo: function (event, row) {
                event.stopPropagation();
                var gridData = row.grid.options.data;
                var rowIndex = gridData.indexOf(row.entity);
                ResourceFactory.Appliance().get({'id': row.entity.id}).$promise.then(function (data) {
                    gridData[rowIndex] = data;
                });
            },
            onDownload: function () {
                ApplianceDownloadFactory.decideDownload();
            }
        };
        scope.instanceActionHandler = {
            onSave: function (event, row) {
                event.stopPropagation();
                row.grid.api.rowEdit.raise.saveRow(row.entity);
            },
            onUndo: function (event, row) {
                event.stopPropagation();
                var gridData = row.grid.options.data;
                var rowIndex = gridData.indexOf(row.entity);
                ResourceFactory.ApplianceInstance().get({'id': row.entity.id}).$promise.then(function (data) {
                    gridData[rowIndex] = data;
                });
            },
            onDelete: function (event, row) {
                event.stopPropagation();
                var data = row.grid.options.data;
                data.splice(data.indexOf(row.entity), 1);
                if (!!row.entity.id) {
                    ResourceFactory.ApplianceInstance().remove({'id': row.entity.id});
                }
            },
            onAuthorize: function (event, row) {
                event.stopPropagation();
                row.entity.activated = !row.entity.activated;
                row.grid.api.rowEdit.raise.saveRow(row.entity);
            },
            addRow: function (event) {
                event.stopPropagation();
                var rowCount = scope.subGridApi.grid.options.data.length;
                var applId = scope.subGridApi.grid.options.applianceId;
                scope.subGridApi.grid.options.data.push({
                    'id': null,
                    'instanceName': 'New Appliance Instance ' + (rowCount + 1),
                    'activationKey': null,
                    'status': 0,
                    'activated': false,
                    'appliance': {'id': applId}
                });
                interval(function () {
                    scope.subGridApi.rowEdit.setRowsDirty([scope.subGridApi.grid.options.data[rowCount]]);
                }, 1, 1);
            }
        };
    }]);
})();

