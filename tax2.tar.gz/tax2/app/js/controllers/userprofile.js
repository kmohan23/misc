/* global angular */
/* global sessionStorage */

(function () {
    'use strict';

    angular.module('lcio')
    .controller('UserProfileModalInstanceCtrl', ['$scope', '$modalInstance', '$timeout', 'fromType', 'ResourceFactory', 'ApplianceDownloadFactory',
    function (scope, modalInstance, timeout, fromType, ResourceFactory, ApplianceDownloadFactory) {

        console.log('UserProfileModalInstanceCtrl : fromType=' + fromType);

        scope.userInfo = {};
        scope.formErrorString = '';

        modalInstance.setMyData = function (uinfo) {
            scope.userInfo = uinfo;
        };

        scope.ok = function () {

            var restObj = angular.copy(scope.userInfo);

            ResourceFactory.UserProfile().update({}, restObj).$promise.then(function (data) {

                modalInstance.dismiss('dismissed');

                if (fromType === 'from-appliance-download') {
                    ApplianceDownloadFactory.decideDownload();
                }
            }, function (error) {
                scope.setWithTimeout('formErrorString', 'Save Failed');
            });
        };

        scope.cancel = function () {
            modalInstance.dismiss('cancel');
        };

        scope.setWithTimeout = function (name, val) {
            scope[name] = val;
            timeout(function () {
                scope[name] = '';
            }, 5000);
        };

    }]);
})();

