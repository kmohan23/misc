/* global angular */

(function () {

    'use strict';

    angular.module('lcio')
    .controller('PartnerProfileModalInstanceCtrl', ['$scope', '$modalInstance', '$timeout', 'ResourceFactory',
    function (scope, modalInstance, timeout, ResourceFactory) {

        console.log('PartnerProfileModalInstanceCtrl');

        scope.partnerInfo = {};
        scope.formErrorString = '';

        modalInstance.setMyData = function (uinfo) {
            scope.partnerInfo = uinfo;
        };

        scope.ok = function () {

            var restObj = angular.copy(scope.partnerInfo);

            ResourceFactory.PartnerProfile().update({}, restObj).$promise.then(function () {
                modalInstance.dismiss('dismissed');
            }, function () {
                scope.setWithTimeout('formErrorString', 'Save Failed');
            });
        };

        scope.cancel = function () {
            modalInstance.dismiss('cancel');
        };

        scope.setWithTimeout = function (name, val) {
            scope[name] = val;
            timeout(function () {
                scope[name] = '';
            }, 5000);
        };

    }]);
})();

