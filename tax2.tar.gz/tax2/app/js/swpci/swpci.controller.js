/* global angular */
/* global _ */

(function () {
    'use strict';

    angular.module('lcio.swpci')
    .controller('SwPciController', ['$scope', '$log', '$modal', '$stateParams', '$eventSock', 'LoginService',
    function (scope, log, modal, stateParams, eventSock, LoginService) {


        log.info('Controller === SwPciController');

        // Initialize chord chart

        scope.pciObj = {};
        LoginService.getLoginUser().then(function (loginUser) {
            if (loginUser === null) {
                log.error('Failed to get LoginUser, WebSocket cannot be initialized.');
            } else {
                var tenantId = loginUser.tenants[stateParams.activeTenantIndex]['id'];
                scope.activeTenantId = tenantId;

                console.log('Printing Tenant ID');
                console.log(scope.activeTenantId);

                eventSock.addStream('/pciscope', function (evt) {
                    log.debug('received a pciScope event from websocket', evt);
                    if (angular.isUndefined(evt) || !angular.isObject(evt)) {
                        return;
                    }
                    log.debug('PCI Scope update', evt);

                    var pciData = [];
                    var scopeColorClasses = ['bundle-node-pci-int-in', 'bundle-node-pci-ext-in', 'bundle-node-pci-int-out', 'bundle-node-pci-ext-out'];
                    var ipScopes = ['InternalIn', 'ExternalIn', 'InternalOut', 'ExternalOut'];


                    // This will be soon moved out in a factory as all conversations would also need it
                    function getFormattedIp(ip) {

                        var arr = ip.split('.');
                        var formattedIp = '';
                        var str = '';
                        var len = arr.length;

                        for (var j = 0; j < len; j ++) {

                            if (arr[j].length === 2) {
                                str = '0' + arr[j];
                            } else if (arr[j].length === 1) {
                                str = '00' + arr[j];
                            } else {
                                str = arr[j];
                            }

                            if (j < (len-1)) {
                                formattedIp = formattedIp + str + '.';
                            } else {
                                formattedIp = formattedIp + str;
                            }
                        }
                        return formattedIp;
                    }

                    var ipObj = {};
                    var formattedIpObject = {};

                    angular.forEach(evt, function (array, index) {

                        var scopeColorClass = scopeColorClasses[index];
                        var ipScope = ipScopes[index];
                        angular.forEach(array, function (obj) {
                            obj['scopeColorClass'] = scopeColorClass;
                            obj['ipScope'] = ipScope+','+obj['ip'];
                            obj['scope'] = ipScope;
                            ipObj[obj['ip']] = obj;
                            formattedIpObject[getFormattedIp(obj['ip'])] = obj;
                        });
                        Array.prototype.push.apply(pciData, array);
                    });

                    angular.forEach(pciData, function (array) {
                        for (var key in array.metrics) {
                           var obj = ipObj[key];

                           if (!obj) {

                              obj = {};
                              obj.metrics = {};
                              obj.ip = key;

                              var pattern = /^192.168/.test(obj.ip);
                              if (pattern) {
                                  obj.scope = ipScopes[0];
                                  obj.scopeColorClass = scopeColorClasses[0];
                              } else {
                                  obj.scope = ipScopes[3];
                                  obj.scopeColorClass = scopeColorClasses[3];
                              }

                              obj['ipScope'] = obj.scope+','+obj['ip'];
                              formattedIpObject[getFormattedIp(obj['ip'])] = obj;
                           }

                           var temp = array.metrics[key];
                           array.metrics[obj.scope+','+key] = temp;
                           delete array.metrics[key];
                        }
                    });

                    var inInkeys = [];
                    var inOutKeys = [];
                    var extInKeys = [];
                    var extOutKeys = [];

                    _.each(formattedIpObject, function (val, key) {

                        if (val.scope === 'InternalOut') {
                            inOutKeys.push(key);
                        } else if (val.scope === 'ExternalIn') {
                            extInKeys.push(key);
                        } else if (val.scope === 'ExternalOut') {
                            extOutKeys.push(key);
                        } else {
                            inInkeys.push(key);
                        }
                    });

                    inOutKeys.sort();
                    extInKeys.sort();
                    extOutKeys.sort();
                    inInkeys.sort();

                    var pciKeys = extInKeys.concat(extOutKeys, inOutKeys, inInkeys);

                    var pciArray = [];

                    for (var k = 0; k < pciKeys.length; k++) {
                        pciArray.push(formattedIpObject[pciKeys[k]]);
                    }


                    scope.pciObj = pciArray;
                    scope.$apply();
                }, tenantId);
            }
        });

        // IMPORT (CSV FILE UPLOAD) -- file selection form

        scope.importModalWindow = null;

        scope.showImportModal = function () {
            log.info('showImportModal');

            scope.importModalWindow = modal.open({
                templateUrl: 'templates/partials/swpci/import-modal.html',
                controller: 'SwpciImportController',
                backdrop: 'static',
                keyboard: false
            });

            scope.importModalWindow.opened.then(function () {
                log.info('import modal opened at: ' + new Date());
            }, function () {
                log.info('import modal dismissed at: ' + new Date());
            });
        };

        scope.openModal = function () {
            modal.open({
                templateUrl: 'templates/partials/modals/swpci-modal.html',
                windowTemplateUrl: 'templates/partials/modals/dashboard-modal-root.html',
                scope: scope,
                backdrop: false
            });
        };

        scope.$on('$destroy', function () {
            var tenantId = scope.activeTenantId;
            console.log('Printing Remove TenantId');
            console.log(tenantId);
            eventSock.removeStream('/pciscope', tenantId);
        });

    }]);

})();
