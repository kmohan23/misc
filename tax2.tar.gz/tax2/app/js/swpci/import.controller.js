/* global angular */
/* global event */
/* global FormData */
/* global alert */

(function () {
    'use strict';

    angular.module('lcio.swpci')
    .controller('SwpciImportController', ['$scope', '$log', '$modalInstance', '$http', 'LoginUserService', '$timeout',
    function (scope, log, modalInstance, http, LoginUserService, timeout) {

        log.info('Controller === SwpciImportController');

        scope.uploadFile = null;
        scope.fileSelected = false;
        scope.showSuccess = false;
        scope.showFailure = false;


        scope.setImportFilename = function (event) {
            var fileObj = event.target.files[0];
            log.info('filename is "' + fileObj.name + '"');
            scope.uploadFile = fileObj;
            scope.fileSelected = true;
        };

        // SAVE

        scope.submitForm = function () {
            log.info('submitForm');

            // We need to look up our current active tenant because it's included in the URL.
            LoginUserService.getCurrentTenant().then(
                // success callback - we found a tenant object
                function (tenant) {
                    scope.postFormToBackEnd(tenant['id']);
                },
                // error callback - we did not find a tenant object
                function (reason) {
                    log.error('error looking up tenant: ' + reason);
                    // TODO - return error here?  alert?  set form error in scope
                }
            );
        };

        // TODO - should this be in a separate resource or service?  probably
        scope.postFormToBackEnd = function (tenantId) {

            var uploadUrl = '/model/tenant/' + tenantId + '/pciscope/import';

            http({
                url: uploadUrl,
                method: 'POST',
                headers: { 'Content-Type': undefined },
                transformRequest: function (data) {
                    var formData = new FormData();
                    // TODO - better name than 'file', change on WFE and WBE at the same time.
                    formData.append('file', scope.uploadFile);
                    return formData;
                }
            }).success(function (resp) {
                log.info('upload succeeded', resp);
                scope.setWithTimeout('showSuccess');
                scope.removeForm(1000, resp);
            }).error(function (err) {
                log.info('upload failed', err);
                scope.setWithTimeout('showFailure');
                scope.removeForm(1000, err);
            });
        };

        // CANCEL button
        scope.cancelForm = function () {
            log.info('cancelled form');
            modalInstance.dismiss('cancel');
        };

        scope.removeForm = function (delay, reason) {
            log.info(reason);
            timeout(function () {
                if(reason.status === 200) {
                    modalInstance.close(reason);
                } else {
                    modalInstance.dismiss(reason);
                }
            }, delay);
        };

        scope.setWithTimeout = function (name) {
            scope[name] = true;
            timeout(function () {
                scope[name] = false;
            }, 1000);
        };

    }])

    .directive('customOnChange', function () {
        return {
            restrict: 'A',
            link: function (scope, element, attrs) {
                var onChangeFunc = scope.$eval(attrs.customOnChange);
                element.bind('change', onChangeFunc);
            }
        };
    });


})();

