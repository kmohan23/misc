/* global angular */
/* global Highcharts */


(function () {
    'use strict';
    angular.module('lcio.twdetail')
    .directive('lcioSfpsTrend', function () {
        return {
            scope: {
                chartOptions: '=chartOptions'
            },
            controller: ['$scope', '$element', '$attrs', '$log',
                function ($scope, $element, $attrs, $log) {

                    $scope.fullOptions = {
                        chart: {
                            type: 'column',
                            zoomType: 'x',
                            spacingBottom: -30,
                            renderTo: false
                        },
                        exporting: {
                            enabled: false
                        },
                        title: {
                            text: 'Stitched Flows per Second',
                            margin: 0,
                            align: 'left',
                            floating: false,
                            style: {
                                fontSize: '14px'
                            }
                        },
                        subtitle: {
                            text: ''
                        },
                        legend: {
                            enabled: false,
                            align: 'right',
                            verticalAlign: 'bottom',
                            layout: 'horizontal',
                            x: -5,
                            floating: true,
                            y: -100,
                            backgroundColor: '#FFFFFF',
                            symbolWidth: 0,
                            itemStyle: {color: '#c6c6c6', fontFamily: 'Arial'}
                        },
                        credits: {
                            enabled: false
                        },
                        xAxis: {
                            type: 'datetime',
                            minorGridLineWidth: 0,
                            lineColor: 'transparent',
                            minorTickLength: 0,
                            tickPixel: 1,
                            tickLength: 0,
                            lineWidth: 0,
                            labels: {
                                format: '{value:%b %d, %Y}',
                                color: '#595959',
                                step: 3,
                                align: 'left',
                                floating: true,
                                rotation: '-45',
                                style: {
                                    fontSize: '9px',
                                    fontFamily: 'Verdana, sans-serif'
                                }
                            },
                            categories: []
                        },
                        yAxis: {
                            ceiling: 50000,
                            gridLineDashStyle: 'shortdash',
                            gridLineColor: 'transparent',
                            labels: {
                                formatter: function () {
                                    return Highcharts.numberFormat(this.value < 50000 && this.value > 0 ? this.value : 0, 0, null, null);
                                }
                            },
                            title: {
                                text: ''
                            }
                        },
                        plotOptions: {
                            column: {
                                borderWidth: 0,
                                grouping: false,
                                stacking: false,
                                events: {
                                    legendItemClick: function () {
                                        return false;
                                    }
                                }
                            }
                        },
                        series: [{
                            name: 'Stitched Flows per Sec',
                            color: '#e6e6e6',
                            pointStart: Date.UTC(2015, 0, 1),
                            pointInterval: 365 * 24 * 3600 * 1000,
                            data: [1, 2, 3, {y: 32500, color: '#ffa7dd'}]
                        }]
                    };

                    this.redraw = function () {
                        $log.debug('lcioSfpsTrend directive "redraw" called');

                        var src = $scope.chartOptions['series_data'];
                        var cnt = src.length;
                        $scope.fullOptions.series[0].pointWidth = 3;
                        $scope.fullOptions.series[0]['pointStart'] = $scope.chartOptions['series_pointStart'];
                        $scope.fullOptions.series[0]['pointInterval'] = $scope.chartOptions['series_pointInterval'];

                        var hwm = 100;
                        for (var i = 0; i < $scope.fullOptions.series[0]['data'].length; i++) {
                            var dVal = $scope.fullOptions.series[0]['data'][i];
                            hwm = dVal > hwm ? dVal : hwm;
                        }
                        $scope.fullOptions.yAxis.tickInterval = 100 * (hwm / 100).toFixed(0);

                        var newData = new Array(365 - cnt).join('1').split('').map(parseFloat);
                        for (var j = 0; j < cnt; j++) {
                            newData.push($scope.chartOptions['series_data'][j]);
                        }
                        $scope.fullOptions.series[0]['data'] = newData;
                        $log.debug('rendering new SFPS chart, options = ', $scope.fullOptions);
                        $scope.chart = new Highcharts.Chart($scope.fullOptions);
                    };

                }],

            link: function (scope, el, attrs, ctrl) {
                scope.fullOptions.chart.renderTo = el[0];
                scope.$watchCollection('chartOptions', function (newVal) {
                    if (!!newVal) {
                        ctrl.redraw();
                    }
                });


            }


        };
    });
})();
