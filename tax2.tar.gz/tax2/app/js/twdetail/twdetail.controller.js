/* global angular */

(function () {
    'use strict';
    angular.module('lcio.twdetail')
    .controller('TwDetailController', ['$scope', '$log', '$eventSock', '$modal', '$stateParams', 'ApplianceDownloadFactory', 'LoginService', 'ResourceFactory', 'ThreatService',
    function (scope, log, eventSock, modal, stateParams, ApplianceDownloadFactory, LoginService, ResourceFactory, ThreatService) {

        log.info('Controller === TwDetailController');

        scope.lcioApplianceTrendOptions = {
            'title_text': '',
            'series_data': [],
            'series_pointInterval': 0,
            'series_pointStart': 0,
            'series_name': 'Need name'
        };

        scope.lcioInternalUniqueIpsTrendOptions = {
            'series_data': [],
            'series_pointInterval': 0,
            'series_pointStart': 0
        };

        scope.lcioTopProtocolsOptions = {
            'series_data': []
        };

        scope.lcioTopTalkersOptions = {
            'series_data': {}
        };
        scope.masterPointList = [];

        scope.currentLicenseMetric = [];

        LoginService.getLoginUser().then(function (loginUser) {
            if (loginUser === null) {
                log.error('Failed to get LoginUser, WebSocket cannot be initialized.');
            } else {
                var tenantId = loginUser.tenants[stateParams.activeTenantIndex]['id'];
                scope.activeTenantId = tenantId;
                eventSock.addStream('/internalUniqueIps', function (evt) {
                    //log.debug('received a stichedFPS event from websocket', evt);
                    if (angular.isUndefined(evt) || !angular.isObject(evt)) {
                        return;
                    }
                    log.debug('update stitchedflows');
                    scope.lcioInternalUniqueIpsTrendOptions['hasCurrentData']       = scope.currentLicenseMetric.length > 0;
                    scope.lcioInternalUniqueIpsTrendOptions['series_data']          = evt.data;
                    scope.lcioInternalUniqueIpsTrendOptions['series_data']          = scope.lcioInternalUniqueIpsTrendOptions['series_data'].concat(scope.currentLicenseMetric);
                    scope.lcioInternalUniqueIpsTrendOptions['series_pointInterval'] = evt.pointInterval;
                    scope.lcioInternalUniqueIpsTrendOptions['series_pointStart']    = evt.pointStart;
                    scope.lcioInternalUniqueIpsTrendOptions['actual_license_size']  =  (loginUser.tenants[stateParams.activeTenantIndex].license) ? loginUser.tenants[stateParams.activeTenantIndex].license.size : 0;
                    scope.$apply();
                }, tenantId);
                eventSock.addStream('/currentLicenseMetric', function (evt) {
                    //log.debug('received a stichedFPS event from websocket', evt);
                    if (angular.isUndefined(evt) || !angular.isObject(evt)) {
                        return;
                    }
                    log.debug('printing currentLicenseMetric ' + evt);
                    scope.currentLicenseMetric = evt.data;
                }, tenantId);
                eventSock.addStream('/appliancetrends', function (evt) {
                    //log.debug('received a applianceTrends event from websocket', evt);
                    if (angular.isUndefined(evt) || !angular.isArray(evt)) {
                        return;
                    }

                    if (evt.length > 0) {
                        log.debug('update applianceTrends');
                        scope.lcioApplianceTrendOptions['series_data'] = evt;
                        scope.$apply();
                    }
                }, tenantId);
                eventSock.addStream('/toptalkers', function (evt) {
                    //log.debug('received a toptalkers event from websocket', evt);
                    if (angular.isUndefined(evt) || !angular.isArray(evt)) {
                        return;
                    }

                    if (evt.length > 0) {

                        var count = evt.length > 10 ? 10 : evt.length; // Limit 100
                        log.debug('update toptalkers');

                        var evtData = evt.slice(0, count);
                        log.debug(evtData);

                        var index, len;
                        for (index = 0, len = evtData.length; index < len; index++) {
                            var ip = evtData[index]['ip'];
                            if (!(ip in scope.masterPointList)) {
                                scope.masterPointList[ip] = {};
                                scope.masterPointList[ip]['type'] = 'point_unknown';
                            }

                            if (scope.masterPointList[ip]['type'] === 'point_unknown') {
                                log.debug('request threat info for [' + ip + ']');

                                // jshint loopfunc: true
                                ThreatService.ipThreatInfo(ip).then(function (result) {
                                    var ip = result.ip;
                                    var score = result.ciscoThreat.score;
                                    // log.debug('response threat info for [' + ip + '] = ' + score);
                                    if (ip in scope.masterPointList) {
                                        scope.masterPointList[ip]['score'] = score;
                                        var type = 'point_unknown';
                                        if (score === null) {
                                            type = 'point_noscore';
                                        } else {
                                            if (score <= -6.0) {
                                                type = 'point_high';
                                            }
                                            else if (score <= 3.0) {
                                                type = 'point_medium';
                                            }
                                            else {
                                                type = 'point_low';
                                            }
                                        }
                                        // log.debug('setting color of point [' + ip + '] to ' + type);
                                        scope.masterPointList[ip]['type'] = type;

                                        var obj = {};
                                        obj.topTalkersData = evtData;
                                        obj.threatData = scope.masterPointList;

                                        scope.lcioTopTalkersOptions['series_data'] = obj;
                                    }
                                });
                            }

                        }
                    }
                }, tenantId);
                //eventSock.addStream('/traffic', function (evt) {
                //    //log.debug('received a traffic event from websocket', evt);
                //    if (angular.isUndefined(evt) || !angular.isObject(evt)) {
                //        return;
                //    }
                //}, tenantId);
            }
        });

        scope.openModal = function (type) {

            var tempUrl = '';

            if (type === 'myappliance') {
                tempUrl = 'templates/partials/modals/myappliance-modal.html';
            } else if (type === 'license') {
                tempUrl = 'templates/partials/modals/license-modal.html';
            } else if (type === 'toptalkers') {
                tempUrl = 'templates/partials/modals/toptalkers-modal.html';
            } else {
                log.error('openModal: unknown modal ' + type);
            }

            modal.open({

                templateUrl: tempUrl,
                windowTemplateUrl: 'templates/partials/modals/dashboard-modal-root.html',
                scope: scope,
                backdrop: false
            });
        };

        scope.openAddApplianceModal = function () {

            var modalInstance = modal.open({

                templateUrl: 'templates/partials/modals/applianceGridNew.html',
                controller: 'ApplianceControllerNew',
                scope: scope,
                resolve: {
                    instanceData: function () {
                        return {};
                    }
                },
                backdrop: 'static',
                keyboard: false
            });

            modalInstance.opened.then(function () {
                ResourceFactory.Appliance().query().$promise.then(function (appData) {

                    if (appData && appData.length > 0) {
                        ResourceFactory.Appliance().instances({'id': appData[0].id}).$promise.then(function (data) {
                            if (data && data.length > 0) {
                                modalInstance.init(data[0]);
                            }
                            else {
                                modalInstance.init({appliance: appData[0]});
                            }
                        });
                    }
                });
            }, function () {
                log.info('Modal dismissed at: ' + new Date());
            });
        };

        scope.downloadAppliance = function () {

            ApplianceDownloadFactory.decideDownload();
        };

        scope.openChordModal = function () {

            modal.open({

                templateUrl: 'templates/partials/modals/ip-chord.html',
                controller: 'ChordController',
                size: 'lg',
                backdrop: 'static',
                keyboard: false
            });
        };

        scope.upgradeAppliance = function (fromType) {

            var modalInstance = modal.open({

                templateUrl: 'templates/partials/modals/upgrade-license.html',
                controller: 'UpgradeModalInstanceCtrl',
                resolve: {
                    licenses: function () {
                        return 'licenses';
                    },
                    fromType: function () {
                        return fromType;
                    }
                },
                backdrop: 'static',
                keyboard: false
            });

            modalInstance.opened.then(function () {
                ResourceFactory.GetLicense().query().$promise.then(function (data) {
                    modalInstance.init(data);
                });
            }, function () {
                log.info('Modal dismissed at: ' + new Date());
            });
        };

        scope.$on('$destroy', function () {
            var tenantId = scope.activeTenantId;
            eventSock.removeStream('/internalUniqueIps', tenantId);
            eventSock.removeStream('/currentLicenseMetric', tenantId);
            eventSock.removeStream('/appliancetrends', tenantId);
            eventSock.removeStream('/toptalkers', tenantId);
            //eventSock.removeStream('/traffic', tenantId);
        });
    }]);
})();

