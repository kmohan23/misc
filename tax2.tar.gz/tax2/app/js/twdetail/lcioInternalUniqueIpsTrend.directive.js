/* global angular */
/* global Highcharts */


(function () {
    'use strict';
    angular.module('lcio.twdetail')
    .directive('lcioInternalUniqueIpsTrend', ['ResourceFactory', function (ResourceFactory) {
        return {
            scope: {
                chartOptions: '=chartOptions'
            },
            controller: ['$scope', '$element', '$attrs', '$log',
                function ($scope, $element, $attrs, $log) {
                    $scope.fullOptions = {
                        chart: {
                            type: 'column',
                            zoomType: 'x',
                            spacingBottom: -30,
                            renderTo: false
                        },
                        exporting: {
                            enabled: false
                        },
                        title: {
                            text: '',
                            margin: 0,
                            align: 'left',
                            floating: false,
                            style: {
                                fontSize: '14px'
                            }
                        },
                        subtitle: {
                            text: ''
                        },
                        legend: {
                            enabled: false,
                            align: 'right',
                            verticalAlign: 'bottom',
                            layout: 'horizontal',
                            x: -5,
                            floating: true,
                            y: -100,
                            backgroundColor: '#FFFFFF',
                            symbolWidth: 0,
                            itemStyle: {color: '#c6c6c6', fontFamily: 'Arial'}
                        },
                        credits: {
                            enabled: false
                        },
                        xAxis: {
                            type: 'datetime',
                            minorGridLineWidth: 0,
                            lineColor: 'transparent',
                            minorTickLength: 0,
                            tickPixel: 1,
                            tickLength: 0,
                            lineWidth: 0,
                            labels: {
                                format: '{value:%m/%d/%y}',
                                color: '#595959',
                                step: 3,
                                align: 'left',
                                floating: true,
                                rotation: '-90',
                                style: {
                                    fontSize: '9px',
                                    fontFamily: 'Verdana, sans-serif'
                                }
                            },
                            categories: []
                        },
                        yAxis: {
                            lineColor: 'lightgrey',
                            lineWidth: 1,
                            gridLineColor: 'transparent',
                            labels: {},
                            title: {
                                text: ''
                            }
                        },
                        plotOptions: {
                            column: {
                                borderWidth: 0,
                                grouping: false,
                                stacking: false,
                                events: {
                                    legendItemClick: function () {
                                        return false;
                                    }
                                }
                            }
                        },
                        series: [{
                            name: 'Internal IP Count',
                            color: '#e6e6e6',
                            pointStart: Date.UTC(2015, 0, 1),
                            pointInterval: 365 * 24 * 3600 * 1000,
                            data: [1, 2, 3, {y: 32500, color: '#ffa7dd'}]
                        }]
                    };

                    this.redraw = function () {

                        ResourceFactory.GetLicense().query().$promise.then(function (licenseArr) {
                            $log.debug('lcioInternalUniqueIPsTrend directive "redraw" called');

                            var src = $scope.chartOptions['series_data'];
                            var cnt = src.length;
                            $scope.fullOptions.series[0].pointWidth = 3;
                            $scope.fullOptions.series[0]['pointStart'] = new Date().setDate(new Date().getDate() - 90);
                            $scope.fullOptions.series[0]['pointInterval'] = $scope.chartOptions['series_pointInterval'];
                            var newData = new Array(90 - cnt).join('1').split('').map(parseFloat);

                            if ($scope.chartOptions['hasCurrentData']) {
                                newData.concat([1, 1]);
                            } else {
                                newData.push(1);
                            }

                            for (var j = 0; j < cnt; j++) {
                                newData.push($scope.chartOptions['series_data'][j]);
                            }

                            $scope.fullOptions.series[0]['data'] = newData;

                            // Start of populating Y axis Logic

                            var licenseSize = $scope.chartOptions['actual_license_size'];

                            $scope.fullOptions.yAxis.min = licenseSize;

                            var maxData = Math.max.apply(null, $scope.fullOptions.series[0]['data']);
                            if (maxData === 0) {
                                maxData++;
                            }
                            var maxLimit;
                            var maxLimitForPlotBand;

                            if (maxData > licenseArr[licenseArr.length - 1].size) {

                                maxLimitForPlotBand = licenseArr[licenseArr.length - 1].size;
                                maxLimit = licenseArr[licenseArr.length - 1].size + 4096;
                            } else {

                                for (var l = 0; l < licenseArr.length; l++) {

                                    if (maxData <= licenseArr[l].size) {

                                        var percentVal = (licenseArr[l].size * 25) / 100;
                                        maxLimitForPlotBand = licenseArr[l].size;
                                        maxLimit = licenseArr[l].size + percentVal;
                                        break;
                                    }
                                }
                            }

                            function getLabelValue(val) {

                                var labelVal = '';

                                for (var m = 0; m < licenseArr.length; m++) {

                                    if (val === licenseArr[m].size) {

                                        labelVal = licenseArr[m].size;
                                        break;
                                    }
                                }
                                return labelVal;
                            }

                            var categoryLinks = {};
                            var iterations = maxLimit / 8;

                            var val = licenseSize;
                            categoryLinks[val] = getLabelValue(val);

                            for (var k = 0; k < iterations; k++) {
                                val = val + 8;
                                categoryLinks[val] = getLabelValue(val);
                            }

                            $scope.fullOptions.yAxis.max = maxLimit;
                            $scope.fullOptions.yAxis.tickInterval = 8;
                            $scope.fullOptions.yAxis.labels.formatter = function () {
                                return categoryLinks[this.value];
                            };

                            function getPlotBandsThreshold() {

                                var plotBandsArr = [];

                                for (var n = 0; n < licenseArr.length; n++) {

                                    if (licenseArr[n].size > licenseSize) {

                                        var arr = {
                                            color: 'rgba(255, 192, 76, .5)'
                                        };

                                        arr.from = licenseArr[n].size;
                                        var percentValue = (licenseArr[n].size * 25) / 100;
                                        arr.to = licenseArr[n].size + percentValue;

                                        plotBandsArr.push(arr);

                                        if (maxLimitForPlotBand === licenseArr[n].size) {
                                            break;
                                        }
                                    }
                                }

                                return plotBandsArr;
                            }

                            var thresholdArray = getPlotBandsThreshold();

                            function getPlotBandsLimit() {

                                var plotBandLimitArr = [];

                                for (var p = 0; p < thresholdArray.length - 1; p++) {

                                    var ival = p;

                                    var arr = {
                                        color: 'rgba(234, 107, 61, .3)'
                                    };

                                    arr.from = thresholdArray[ival].to + 1;
                                    arr.to = thresholdArray[++ival].from - 1;

                                    plotBandLimitArr.push(arr);
                                }

                                return plotBandLimitArr;
                            }

                            var plotLimitArr = getPlotBandsLimit();

                            $scope.fullOptions.yAxis.plotBands = thresholdArray.concat(plotLimitArr);

                            // End of populating Y axis Logic

                            $log.debug('rendering new SFPS chart, options = ', $scope.fullOptions);
                            $scope.chart = new Highcharts.Chart($scope.fullOptions);

                        });
                    };

                }],

            link: function (scope, el, attrs, ctrl) {

                scope.fullOptions.chart.renderTo = el[0];
                scope.$watchCollection('chartOptions', function (newVal) {
                    if (!!newVal) {
                        ctrl.redraw();
                    }
                });


            }
        };
    }]);
})();
