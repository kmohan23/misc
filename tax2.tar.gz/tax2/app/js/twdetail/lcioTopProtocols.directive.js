/* global angular */
/* global Highcharts */

(function () {
    'use strict';
    angular.module('lcio.twdetail')
    .directive('lcioTopProtocols', function () {
        return {
            scope: {
                chartOptions: '=chartOptions'
            },
            controller: ['$scope', '$element', '$attrs', '$log',
            function ($scope, $element, $attrs, $log) {

                $scope.fullOptions = {
                    chart: {
                        type: 'bubble',
                        spacingBottom: 0,
                        renderTo: false
                    },
                    exporting: {
                        enabled: false
                    },
                    tooltip: {
                        formatter: function () {
                            return this.point.name + '<b> ' + this.point.z + '%' + '</b>';
                        }
                    },
                    credits: {
                        enabled: false
                    },
                    legend: {
                        enabled: false
                    },
                    plotOptions: {
                        bubble: {
                            dataLabels: {
                                enabled: true,
                                useHTML: true,
                                color: '#000000',
                                x: 0,
                                style: {textShadow: 'none'},
                                formatter: function () {
                                    return '<div style="background-color: #d5eff9; display: block; text-align: center">' + this.point.name + '</div><div style="background-color: #d5eff9; display: block; text-align: center">' + this.point.z + '</div> ';
                                }
                            },
                            minSize: '30%',
                            maxSize: '72%'
                        }
                    },
                    xAxis: {
                        tickLength: 0,
                        lineWidth: 0,
                        labels: {
                            enabled: false
                        }
                    },
                    yAxis: {
                        gridLineColor: 'transparent',
                        labels: {
                            enabled: false
                        },
                        title: {
                            text: ''
                        }
                    },
                    title: {
                        text: '',
                        align: 'left',
                        margin: 0,
                        floating: true,
                        style: {
                            fontSize: '14px'
                        }
                    },
                    series: []

                };
                this.redraw = function () {
                    $log.debug('lcioTopProtocols directive "redraw" called');
                    var protoVals = [];
                    var total = 0;
                    var src = $scope.chartOptions['series_data'];
                    for (var i = 0; i < src.length; i++) {
                        total += src[i].value;
                    }
                    for (var j = 0; j < src.length; j++) {
                        var pname = src[j].name;
                        var pval = (src[j].value * 100 / total).toFixed(2);
                        // TODO - determine reasonable values for color and y... and z?
                        protoVals[j] = {
                            color: 'rgba(77, 176, 227, 0)',
                            data: [{name: pname, x: 25, y: 100 - 10 * j, z: pval}]
                        };
                    }
                    $scope.fullOptions.series = protoVals;
                    $log.debug('rendering new Top Protocols chart, options = ', $scope.fullOptions);
                    $scope.chart = new Highcharts.Chart($scope.fullOptions);
                };
            }],

            link: function (scope, el, attrs, ctrl) {
                scope.fullOptions.chart.renderTo = el[0];
                scope.$watchCollection('chartOptions', function (newVal) {
                    if (!!newVal) {
                        ctrl.redraw();
                    }
                });
            }
        };
    });
})();
