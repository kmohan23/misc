/* global angular */
/* global Highcharts */

(function () {
    'use strict';

    angular.module('lcio.twdetail')
    .directive('lcioApplianceTrend', function () {
        return {
            scope: {
                chartOptions: '=chartOptions'
            },
            controller: ['$scope', '$element', '$attrs', '$log',
            function ($scope,   $element,   $attrs,   $log) {

                $scope.fullOptions = {
                        chart: {
                            type: 'areaspline',
                            backgroundColor: '#f5f5f5',
                            marginBottom: 0,
                            marginLeft: 0,
                            marginRight: 0,
                            marginTop: 0,
                            renderTo: false
                        },
                        exporting: {
                            enabled: false
                        },
                        title: {
                            text: '',
                            margin: 0,
                            align: 'left',
                            floating: false,
                            style: {
                                fontSize: '14px'
                            }
                        },
                        legend: {
                            layout: 'vertical',
                            align: 'right',
                            verticalAlign: 'top',
                            x: 0,
                            y: 10,
                            floating: false,
                            borderWidth: 0,
                            borderRadius: 3,
                            symbolWidth: 0,
                            backgroundColor: (Highcharts.theme && Highcharts.theme.legendBackgroundColor) || '#FFFFFF'
                        },
                        tooltip: {
                            formatter: function () {
                                return '<b>' + new Date(this.x).toLocaleTimeString() + '</b><br/>' + (this.y / (1024 * 1024)).toFixed(2) + ' MB';
                            }
                        },
                        xAxis: {
                            type: 'datetime',
                            dateTimeLabelFormats: {
                                day: '%e of %b'
                            },
                            labels: {
                                enabled: false
                            }
                        },
                        yAxis: {
                            gridLineColor: 'transparent',
                            labels: {
                                enabled: false
                            },
                            title: {
                                text: ''
                            }
                        },
                        credits: {
                            enabled: false
                        },
                        plotOptions: {
                            areaspline: {
                                fillOpacity: 0.5,
                                fillColor: '#00afe0'
                            }
                        }
                    };

                this.redraw = function () {
                    $log.debug('lcioApplianceTrend directive "redraw" called');

                    if (!$scope.chart) {
                        $scope.chart = new Highcharts.Chart($scope.fullOptions);
                    }

                    var src = $scope.chartOptions['series_data'];

                    if ($scope.chart.series.length) {
                        for (var j = 0; j < src.length; j++) {
                            $scope.chart.series[j].remove();
                        }
                    }

                    for (var i = 0; i < src.length; i++) {
                        var seriesObj = src[i];
                        var markerObj = { 'enabled': false };
                        seriesObj.color = '#00afe0';
                        seriesObj.marker = markerObj;
                        $scope.chart.addSeries(seriesObj);
                    }
                    $log.debug('rendering new Appliance Trend chart, options = ', $scope.fullOptions);
                };

            }],
            link: function (scope, el, attrs, ctrl) {
                scope.fullOptions.chart.renderTo = el[0];
                scope.$watchCollection('chartOptions', function (newVal) {
                    if (!!newVal) {
                        ctrl.redraw();
                    }
                });
            }
        };
    }
    );
})();
