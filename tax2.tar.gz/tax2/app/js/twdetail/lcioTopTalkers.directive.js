/* global angular */
/* global Highcharts */


(function () {
    'use strict';
    angular.module('lcio.twdetail')
    .directive('lcioTopTalkers', function () {
        return {
            scope: {
                chartOptions: '=chartOptions'
            },
            controller: ['$scope', '$element', '$attrs', '$log',
                function ($scope, $element, $attrs, $log) {

                    $scope.chart = null;
                    $scope.seriesObj = null;
                    $scope.fullOptions = {
                        chart: {
                            type: 'area',
                            spacingBottom: -30,
                            zoomType: 'x',
                            renderTo: false
                        },
                        exporting: {
                            enabled: false
                        },
                        title: {
                            text: '',
                            margin: 0,
                            align: 'left',
                            floating: false,
                            style: {
                                fontSize: '14px'
                            }
                        },
                        legend: {
                            enabled: false
                        },
                        xAxis: {
                            categories: [],
                            lineWidth: 0,
                            minorGridLineWidth: 0,
                            lineColor: 'transparent',
                            minorTickLength: 0,
                            tickLength: 0,
                            tickPixel: 1,
                            labels: {
                                enabled: true,
                                color: '#595959',
                                align: 'left',
                                floating: true,
                                rotation: '-90',
                                style: {
                                    fontSize: '9px',
                                    fontFamily: 'Verdana, sans-serif'
                                }
                            }
                        },
                        yAxis: [
                            {
                                title: {
                                    text: ''
                                },
                                labels: {
                                    enabled: false
                                },
                                gridLineWidth: 0,
                                minorGridLineWidth: 0
                            }, {
                                title: {
                                    text: ''
                                },
                                labels: {
                                    enabled: true
                                },
                                gridLineWidth: 0,
                                minorGridLineWidth: 0
                            }, {
                                title: {
                                    text: ''
                                },
                                labels: {
                                    enabled: false
                                },
                                gridLineWidth: 0,
                                minorGridLineWidth: 0
                            }
                        ],
                        tooltip: {
                            enabled: true,
                            formatter: function () {

                                var arr = $scope.seriesObj.data.filter(function (data) {
                                    return data.ip === this.x;
                                }.bind(this));
                                return '<div>' + arr[0].dns + '</div><br><div><b>Traffic: </b>' + this.y + '</div>';
                            }
                        },
                        credits: {
                            enabled: false
                        },
                        series: [{
                            type: 'column',
                            name: 'Traffic',
                            colorByPoint: true,
                            data: [],
                            yAxis: 1,
                            pointWidth: 1,
                            grouping: false,
                            dataLabels: {
                                enabled: false
                            }
                        }]
                    };
                    this.redraw = function () {
                        $log.debug('lcioTopTalkers directive "redraw" called');
                        if (!$scope.chart) {
                            $scope.chart = new Highcharts.Chart($scope.fullOptions);
                        }

                        if ($scope.chart.series.length) {
                            $scope.chart.series[0].remove();
                        }

                        $scope.seriesObj = {
                            type: 'column',
                            name: 'Traffic',
                            colorByPoint: true,
                            data: [],
                            yAxis: 1,
                            pointWidth: 1,
                            grouping: false,
                            dataLabels: {
                                enabled: false
                            }
                        };

                        var threatColor = {
                            'point_high': {color: 'red'},
                            'point_medium': {color: 'yellow'},
                            'point_low': {color: 'green'},
                            'point_noscore': {color: '#7AA3B7'},
                            'point_unknown': {color: 'gray'}
                        };

                        if (!$scope.chartOptions['series_data'].hasOwnProperty('topTalkersData')) {
                            $log.debug('No TopTalkers data.');
                        } else {
                            var src = $scope.chartOptions['series_data'].topTalkersData;
                            var threatData = $scope.chartOptions['series_data'].threatData;
                            var cnt = src.length;

                            $scope.seriesObj.pointWidth = 900 / cnt + 1;
                            for (var i = 0; i < cnt; i++) {
                                var ip = src[i].ip;
                                var val = src[i].value / 1024 * 1024 * 1024;  // TODO - proper scaling
                                var host = src[i].host;
                                var color = threatColor[threatData[ip]['type']]['color'];
                                $log.info(val);
                                $scope.fullOptions.xAxis.categories[i] = ip;
                                var obj = {
                                    'y': 0,
                                    'color': color,
                                    'ip': ip,
                                    'dns': host
                                };
                                obj.y = val;
                                $scope.seriesObj.data.push(obj);
                            }
                            $scope.chart.addSeries($scope.seriesObj);
                        }
                    };

                }],

            link: function (scope, el, attrs, ctrl) {
                scope.fullOptions.chart.renderTo = el[0];
                scope.$watchCollection('chartOptions', function (newVal) {
                    if (!!newVal) {
                        ctrl.redraw();
                    }
                });
            }
        };
    });
})();
