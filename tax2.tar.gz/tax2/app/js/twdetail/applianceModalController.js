/* global angular */

(function () {
    'use strict';

    angular.module('lcio.twdetail')
    .controller('ApplianceControllerNew', ['$scope', '$log', '$modalInstance', 'instanceData', 'ResourceFactory', '$timeout',
    function (scope, log, modalInstance, instanceData, ResourceFactory, timeout) {

        log.info('Controller === ApplianceControllerNew');

        scope.formErrorString = null;
        scope.instanceData = instanceData;

        modalInstance.init = function (data) {
            scope.instanceData = data;
        };

        scope.ok = function () {

            scope.instanceData.activated = true;
            log.debug('Save Instance', scope.instanceData);

            if (scope.instanceData.hasOwnProperty('id') && scope.instanceData.id) {
                ResourceFactory.ApplianceInstance().update(scope.instanceData, scope.instanceData).$promise.then(function (data) {
                    modalInstance.dismiss('cancel');
                }, function (resp) {
                    scope.setWithTimeout('formErrorString', 'The appliance key provided is not valid; please recheck your appliance key and try again.');
                });
            } else {
                ResourceFactory.ApplianceInstance().save(scope.instanceData).$promise.then(function (data) {
                    modalInstance.dismiss('cancel');
                }, function (resp) {
                    scope.setWithTimeout('formErrorString', 'The appliance key provided is not valid; please recheck your appliance key and try again.');
                });
            }

        };

        scope.cancel = function () {
            modalInstance.dismiss('cancel');
        };

        scope.setWithTimeout = function (name, val) {
            scope[name] = val;
            timeout(function () {
                scope[name] = '';
            }, 5000);
        };
    }]);
})();
