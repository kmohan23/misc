/* global JSON */

'use strict';

var gulp        = require('gulp'),
    bowerFiles  = require('main-bower-files'),
    stylish     = require('jshint-stylish'),
    path        = require('path'),
    open        = require('open'),
    fs          = require('fs'),
    chalk       = require('chalk'),
    args        = require('yargs').argv,
    map         = require('map-stream'),
    glob        = require('glob'),
    browserSync = require('browser-sync'),
    runSequence = require('run-sequence'),
    proxy       = require('http-proxy-middleware'),
    wrap        = require('gulp-wrap'),
    KarmaServer = require('karma').Server;


/*    gulpPlugins = require('gulp-load-plugins')(); */

var gulpPlugins         = {};
gulpPlugins.compass     = require('gulp-compass');
gulpPlugins.concat      = require('gulp-concat');
gulpPlugins.connect     = require('gulp-connect');
gulpPlugins.filter      = require('gulp-filter');
gulpPlugins['if']       = require('gulp-if');
gulpPlugins.imagemin    = require('gulp-imagemin');
gulpPlugins.jshint      = require('gulp-jshint');
gulpPlugins.minifyCss   = require('gulp-cssnano');
gulpPlugins.minifyHtml  = require('gulp-htmlmin');
gulpPlugins.rename      = require('gulp-rename');
gulpPlugins.rimraf      = require('gulp-rimraf');
gulpPlugins.sass        = require('gulp-sass');
gulpPlugins.taskListing = require('gulp-task-listing');
gulpPlugins.uglify      = require('gulp-uglify');
gulpPlugins.templateCache = require('gulp-angular-templatecache');

// chalk config
var errorLog  = chalk.red.bold,
    hintLog   = chalk.blue,
    changeLog = chalk.red;

var SETTINGS = {
    src: {
        app: 'app/',
        css: 'app/css/',
        js: 'app/js/',
        templates: 'app/templates/',
        images: 'app/img/',
        fonts: 'app/fonts/',
        bower: 'bower_components/',
        shared: 'bower_components/lc-ui-shared-resources/modules/common/',
        sharedUtil: 'bower_components/lc-ui-shared-resources/modules/util/',
        sharedScss: 'app/scss/',
        sharedCompassCfg: 'app/scss/config.rb',
        sharedScssFiles: ['app/scss/font-awesome.scss',
                          'app/scss/fonts.scss',
                          'app/scss/bootstrap-styles.scss',
                          'app/scss/lc-io-global.scss']
    },
    build: {
        app: 'build/',
        shared: 'build/js/',
        sharedHtml: 'build/lib/shared/modules/common/',
        css: 'build/css/',
        js: 'build/js/',
        templates: 'build/templates/',
        images: 'build/images/',
        fonts: 'build/fonts/',
        fontsBootstrap: 'bootstrap/',
        fontsRoboto: 'roboto/',
        fontsLc: 'lc-font/',
        bower: 'build/bower/' // If you change this, you will have to change in index.html as well.
    },
    temp: 'temp/',
    sharedExclude: '!**/lc-ui-shared-resources/**',
    fontawesomeExclude: '!**/fontawesome/**',
    robotoExclude: '!**/roboto-*/**',
    fontFilter: '**/*.{eot,svg,otf,ttf,woff,woff2}',
    fontExcludes: ['**', '!**/bootstrap*/**', '!**/roboto*/**', '!**/lc-font/**']
};

var bowerConfig = {
    paths: {
        bowerDirectory: SETTINGS.src.bower,
        bowerrc: '.bowerrc',
        bowerJson: 'bower.json'
    }
};

//server and live reload config
var serverConfig = {
    root: SETTINGS.build.app,
    host: 'localhost',
    port: 9000,
    livereload: true,
    middleware: function () {
        return [
            proxy('/model', {
                //target: 'http://webbackend:8080',
                target: 'http://10.22.1.53:48082', // DEV
                //target: 'http://10.22.0.89:48082', // QA

                pathRewrite: { '^/model' : '' },
                changeOrigin: true,
                ws: true
            })
        ];
    }
};
// If we're rewriting our /model/ (above) to connect to the DEV or QA environments, then we need
// to tell node.js to ignore the 'Error: unable to verify the first certificate in nodejs' TLS error.
// See http://stackoverflow.com/questions/31673587/error-unable-to-verify-the-first-certificate-in-nodejs
// This does not happen in production, because we do not run the gulp server in that environment.
process.env.NODE_TLS_REJECT_UNAUTHORIZED = 0;

// jsHint Options.
var hintOptions = JSON.parse(fs.readFileSync('.jshintrc', 'utf8'));

// Flag for generating production code.
var isProduction = args.type === 'production';


var cleanFiles = function (files, logMessage) {
    console.log('-------------------------------------------------- CLEAN :' + logMessage);
    gulp.src(files, {read: false})
        .pipe(gulpPlugins.rimraf({force: true}));
};

/*============================================================
=>                          Server
============================================================*/

gulp.task('server', function () {

    console.log('------------------>>>> firing server  <<<<-----------------------');
    gulpPlugins.connect.server(serverConfig);

    console.log('Started connect web server on http://localhost:' + serverConfig.port + '.');
    open('http://localhost:' + serverConfig.port);
});

gulp.task('tasks', gulpPlugins.taskListing);

/*============================================================
=                          JS-HINT                          =
============================================================*/

gulp.task('js:hint', function () {

    console.log('-------------------------------------------------- JS - HINT');
    return gulp.src([SETTINGS.src.js + 'app.js', '!' + SETTINGS.src.js + 'plugins/*.js', '!' + SETTINGS.src.js + 'inc/*.js', SETTINGS.src.js + '**/*.js', 'gulpfile.js'])
        .pipe(gulpPlugins.jshint(hintOptions))
        .pipe(gulpPlugins.jshint.reporter(stylish));
});


/*============================================================
=                          Concat                           =
============================================================*/

gulp.task('concat', ['concat:bower', 'concat:js', 'concat:css', 'tidy:css']);

gulp.task('concat:bower', function () {
    console.log('-------------------------------------------------- CONCAT :bower');

    var jsFilter     = gulpPlugins.filter(['**/*.js',  SETTINGS.sharedExclude], {restore: true});
    var cssFilter    = gulpPlugins.filter(['**/*.css', SETTINGS.sharedExclude, SETTINGS.fontawesomeExclude, SETTINGS.robotoExclude], {restore: true});
    var assetsFilter = gulpPlugins.filter(['!**/*.js', '!**/*.css', '!**/*.scss'], {restore: true});

    return gulp.src(bowerFiles(bowerConfig), {base: SETTINGS.src.bower})
        .pipe(jsFilter)
        .pipe(gulpPlugins.concat('_bower.js'))
        .pipe(gulpPlugins.if(isProduction, gulpPlugins.uglify()))
        .pipe(gulp.dest(SETTINGS.build.bower))
        .pipe(jsFilter.restore)
        .pipe(cssFilter)
        .pipe(gulpPlugins.sass())
        .pipe(map(function (file, callback) {
            var relativePath = path.dirname(path.relative(path.resolve(SETTINGS.src.bower), file.path));

            // CSS path resolving
            // Taken from https://github.com/enyojs/enyo/blob/master/tools/minifier/minify.js
            var contents = file.contents.toString().replace(/url\([^)]*\)/g, function (match) {
                // find the url path, ignore quotes in url string
                var matches = /url\s*\(\s*(('([^']*)')|("([^"]*)")|([^'"]*))\s*\)/.exec(match),
                    url = matches[3] || matches[5] || matches[6];

                // Don't modify data and http(s) urls, or any starting with ../fonts
                if (/^data:/.test(url) || /^http(:?s)?:/.test(url) || /^\.\.\/fonts/.test(url) || /^\.\.\/images/.test(url)) {
                    return 'url(' + url + ')';
                }
                // Modify any relative paths to image files
                if (/.+\.(png|jpg|gif)(\?|#)?.*$/.test(url)) {
                    return 'url(../' + url + ')';
                }
                // Modify any relative paths to font files
                if (/.+\.(eot|svg|ttf|woff|woff2)(\?|#)?.*$/.test(url)) {
                    return 'url(../fonts/' + url + ')';
                }
                return 'url(' + path.join(path.relative(SETTINGS.build.bower, SETTINGS.build.app), SETTINGS.build.bower, relativePath, url) + ')';
            });
            file.contents = new Buffer(contents);

            callback(null, file);
        }))
        .pipe(gulpPlugins.concat('_bower.css'))
        .pipe(gulp.dest(SETTINGS.build.bower))
        .pipe(cssFilter.restore)
        .pipe(assetsFilter)
        .pipe(gulp.dest(SETTINGS.build.bower))
        .pipe(assetsFilter.restore)
        .pipe(gulpPlugins.connect.reload());
});
gulp.task('concat:charts', function () {
    console.log('-------------------------------------------------- CONCAT :charts');
    gulp.src([SETTINGS.src.bower + SETTINGS.chartsFilter])
        .pipe(gulpPlugins.concat('_charts.js'))
        .pipe(gulpPlugins.if(isProduction, gulpPlugins.uglify()))
        .pipe(gulp.dest(SETTINGS.build.bower))
        .pipe(gulpPlugins.connect.reload());
});
gulp.task('concat:maps', function () {
    console.log('-------------------------------------------------- CONCAT :maps');
    gulp.src([SETTINGS.src.bower + SETTINGS.mapsFilter])
        .pipe(gulpPlugins.concat('_maps.js'))
        .pipe(gulpPlugins.if(isProduction, gulpPlugins.uglify()))
        .pipe(gulp.dest(SETTINGS.build.bower))
        .pipe(gulpPlugins.connect.reload());
});

gulp.task('concat:sharedjs', ['js:hint'], function () {

    console.log('-------------------------------------------------- CONCAT :js');
    gulp.src([SETTINGS.src.shared + '**/*.js', SETTINGS.src.sharedUtil + '**/*.js'])
        .pipe(gulpPlugins.concat('shared.js'))
        .pipe(gulpPlugins.if(isProduction, gulpPlugins.uglify()))
        .pipe(gulp.dest(SETTINGS.build.shared))
        .pipe(gulpPlugins.connect.reload());
});
gulp.task('concat:js', ['js:hint'], function () {

    console.log('-------------------------------------------------- CONCAT :js');
    gulp.src([SETTINGS.src.js + 'app.js',
              SETTINGS.src.js + 'app.modules.js',
              SETTINGS.src.js + '**/*.js'])
        .pipe(wrap('// FILE <%= file.path %>\n<%= contents %>'))
        .pipe(gulpPlugins.concat('all.js'))
        .pipe(gulpPlugins.if(isProduction, gulpPlugins.uglify()))
        .pipe(gulp.dest(SETTINGS.build.js))
        .pipe(gulpPlugins.connect.reload());
});

gulp.task('compass:shared', function () {
    console.log('-------------------------------------------------- COMPASS');
    return gulp.src(SETTINGS.src.sharedScssFiles)
        .pipe(gulpPlugins.compass({
            'config_file': SETTINGS.src.sharedCompassCfg,
            'css':  SETTINGS.temp,
            'sass': SETTINGS.src.sharedScss
        })).on('error', function (err) {
            console.log(errorLog('\n Compass SASS file has error, see below log ------------->>> \n'));
            console.log(errorLog(err));
        })
        .pipe(gulpPlugins.concat('shared.css'))
        .pipe(gulp.dest(SETTINGS.build.css));
});

gulp.task('convert:scss', function () {
    console.log('-------------------------------------------------- CONVERT :scss');

    return gulp.src(SETTINGS.src.css + 'application.scss')
         .pipe(gulpPlugins.sass({includePaths: [SETTINGS.src.css]}))
             .on('error', function (err) {
                    console.log(errorLog('\n SASS file has error, see below log ------------->>> \n'));
                    console.log(errorLog(err));
                })
         .pipe(gulp.dest(SETTINGS.build.css))
         .pipe(gulpPlugins.connect.reload());
});

gulp.task('concat:css', ['convert:scss'], function () {

    console.log('-------------------------------------------------- CONCAT :css ');
    return gulp.src([SETTINGS.build.css + 'application.css', SETTINGS.src.css + '*.css'])
               .pipe(gulpPlugins.concat('styles.css'))
               .pipe(gulpPlugins.if(isProduction, gulpPlugins.minifyCss({keepSpecialComments: '*'})))
               .pipe(gulp.dest(SETTINGS.build.css))
               .pipe(gulpPlugins.connect.reload());
});

gulp.task('tidy:css', ['compass:shared'], function () {
    console.log('-------------------------------------------------- TIDY :css');
    cleanFiles([SETTINGS.temp], 'temp');
});


/*============================================================
=                          Minify                            =
============================================================*/

gulp.task('image:min', function () {
    gulp.src(SETTINGS.src.images + '**')
        .pipe(gulpPlugins.imagemin())
        .pipe(gulp.dest(SETTINGS.build.images))
        .pipe(gulpPlugins.connect.reload());
});


/*============================================================
=                           Copy                            =
============================================================*/

gulp.task('copy', ['copy:html', 'copy:images', 'copy:imagesMapbox.js', 'copy:fonts', 'copy:html:root']);


gulp.task('copy:html', function () {

    console.log('-------------------------------------------------- COPY :html');
    gulp.src([SETTINGS.src.templates + '*.html', SETTINGS.src.templates + '**/*.html'])
        .pipe(gulpPlugins.if(isProduction, gulpPlugins.minifyHtml({comments: false, quotes: true, spare: true, empty: true, cdata: true})))
        .pipe(gulp.dest(SETTINGS.build.templates))
        .pipe(gulpPlugins.connect.reload());
});

gulp.task('copy:html:root', function () {

    console.log('-------------------------------------------------- COPY :html:root');
    gulp.src(SETTINGS.src.app + '*.html')
        .pipe(gulpPlugins.if(isProduction, gulpPlugins.minifyHtml({comments: false, quotes: true, spare: true, empty: true, cdata: true})))
        .pipe(gulp.dest(SETTINGS.build.app))
        .pipe(gulpPlugins.connect.reload());
});

gulp.task('copy:htmlshared', function () {

    console.log('-------------------------------------------------- COPY :htmlshared');
    gulp.src(SETTINGS.src.shared + '**/*.html')
        .pipe(gulpPlugins.if(isProduction, gulpPlugins.minifyHtml({comments: false, quotes: true, spare: true, empty: true, cdata: true})))
        .pipe(gulp.dest(SETTINGS.build.sharedHtml))
        .pipe(gulpPlugins.connect.reload());
});

gulp.task('copy:images', function () {

    console.log('-------------------------------------------------- COPY :images');
    gulp.src([SETTINGS.src.images + '*.*', SETTINGS.src.images + '**/*.*'])
        .pipe(gulp.dest(SETTINGS.build.images));
});

gulp.task('copy:imagesMapbox.js', function () {

    console.log('-------------------------------------------------- COPY :mapbox.js images');
    gulp.src([SETTINGS.src.bower + 'mapbox.js/images/*.{svg,png}'])
        .pipe(gulp.dest(SETTINGS.build.images));
});

gulp.task('copy:fonts', ['copy:fontsbootstrap', 'copy:fontsroboto', 'copy:fontslc'], function () {

    console.log('-------------------------------------------------- COPY :fonts');
    gulp.src(SETTINGS.src.bower + SETTINGS.fontFilter)
        .pipe(gulpPlugins.filter(SETTINGS.fontExcludes))
        .pipe(gulpPlugins.rename({dirname: ''}))
        .pipe(gulp.dest(SETTINGS.build.fonts));
});

gulp.task('copy:fontsbootstrap', function () {

    console.log('-------------------------------------------------- COPY :bootstrap fonts');
    gulp.src(glob.sync(SETTINGS.src.bower + 'bootstrap*/' + SETTINGS.fontFilter))
        .pipe(gulp.dest(SETTINGS.build.fonts + SETTINGS.build.fontsBootstrap));
});

gulp.task('copy:fontsroboto', function () {

    console.log('-------------------------------------------------- COPY :roboto fonts');
    gulp.src(glob.sync(SETTINGS.src.bower + 'roboto*/' + SETTINGS.fontFilter))
        .pipe(gulp.dest(SETTINGS.build.fonts + SETTINGS.build.fontsRoboto));
});

gulp.task('copy:fontslc', function () {

    console.log('-------------------------------------------------- COPY :LC fonts');
    gulp.src([SETTINGS.src.fonts + SETTINGS.build.fontsLc + SETTINGS.fontFilter])
        .pipe(gulp.dest(SETTINGS.build.fonts + SETTINGS.build.fontsLc));
});

/*=============================================================================

    Fetch Templates and put in a TemplateCache JS container

==============================================================================*/

gulp.task('template:js', function () {

    console.log(hintLog('-------------------------------------------------- template:js'));
    return gulp.src(SETTINGS.src.templates + 'partials/partner/*.html')
        .pipe(gulpPlugins.templateCache('templates.js', {module: 'lcio.templates'}))
        .pipe(wrap('(function(){\n"use strict";\n<%= contents %>\n})();'))
        .pipe(gulp.dest(SETTINGS.build.js))
        .pipe(gulpPlugins.connect.reload());
});

/*=========================================================================================================
=                                                Watch
    If the watch fails due to limited number of watches available on your system,
    then execute this command on terminal:

    $ echo fs.inotify.max_user_watches=524288 | sudo tee -a /etc/sysctl.conf && sudo sysctl -p
=========================================================================================================*/

gulp.task('watch', function () {

    console.log('watching all the files.....');

    var watchedFiles = [];

    watchedFiles.push(gulp.watch([SETTINGS.src.css + '*.css',  SETTINGS.src.css + '**/*.css'],  ['concat:css']));
    watchedFiles.push(gulp.watch([SETTINGS.src.css + '*.scss', SETTINGS.src.css + '**/*.scss'], ['concat:css']));
    watchedFiles.push(gulp.watch([SETTINGS.src.js + '*.js',    SETTINGS.src.js + '**/*.js'],    ['concat:js']));
    watchedFiles.push(gulp.watch([SETTINGS.src.app + '*.html'], ['copy:html:root']));
    watchedFiles.push(gulp.watch([SETTINGS.src.images + '*.*', SETTINGS.src.images + '**/*.*'], ['copy:images']));
    watchedFiles.push(gulp.watch([SETTINGS.src.fonts + '*.*',  SETTINGS.src.fonts + '**/*.*'],  ['copy:fonts']));
    watchedFiles.push(gulp.watch([SETTINGS.src.bower + '*.js', SETTINGS.src.bower + '**/*.js'], ['concat:bower']));
    watchedFiles.push(gulp.watch([SETTINGS.src.templates + '*.html', SETTINGS.src.templates + '**/*.html'], ['copy:html', 'template:js']));

    // Just to add log messages on Terminal, in case any file is changed
    var onChange = function (event) {
        if (event.type === 'deleted') {
            runSequence('clean');
            setTimeout(function () {
                runSequence('copy', 'concat', 'template:js', 'watch');
            }, 500);
        }
        console.log(changeLog('-------------------------------------------------->>>> File ' + event.path + ' was ------->>>> ' + event.type));
    };

    watchedFiles.forEach(function (watchedFile) {
        watchedFile.on('change', onChange);
    });

});


/*============================================================
=                             Clean                          =
============================================================*/

gulp.task('clean', function () {
    cleanFiles([SETTINGS.build.app], 'all files');
});

gulp.task('clean:css', function () {
    cleanFiles([SETTINGS.build.css], 'css');
});

gulp.task('clean:js', function () {
    cleanFiles([SETTINGS.build.js], 'js');
});

gulp.task('clean:html', function () {
    cleanFiles([SETTINGS.build.templates], 'html');
});

gulp.task('clean:images', function () {
    cleanFiles([SETTINGS.build.images], 'images');
});

gulp.task('clean:fonts', function () {
    cleanFiles([SETTINGS.build.fonts + '*.*', SETTINGS.build.fonts + '**/*.*'], 'fonts');
});

gulp.task('clean:zip', function () {
    cleanFiles(['zip/**/*', '!zip/build-*.zip'], 'zip');
});



/*============================================================
=                             Zip                          =
============================================================*/

gulp.task('zip', function () {
    gulp.src([SETTINGS.build.app + '*', SETTINGS.build.app + '**/*'])
        .pipe(gulpPlugins.zip('build-' + new Date() + '.zip'))
        .pipe(gulp.dest('./zip/'));

    setTimeout(function () {
        runSequence('clean:zip');
    }, 500); // wait for file creation

});

/*============================================================
=                             Start                          =
============================================================*/


gulp.task('build', function () {
    console.log(hintLog('-------------------------------------------------- BUILD - Development Mode'));
    runSequence('copy', 'concat', 'template:js');
});

gulp.task('build:prod', function () {
    console.log(hintLog('-------------------------------------------------- BUILD - Production Mode'));
    isProduction = true;
    runSequence('copy', 'concat', 'template:js');
});

gulp.task('default', ['build', 'watch', 'server']);

// Just in case you are too lazy to type: $ gulp --type production
gulp.task('prod', ['build:prod', 'watch', 'server']);


/*============================================================
=                       Browser Sync                         =
============================================================*/

gulp.task('bs', function () {
    browserSync.init([SETTINGS.build.app + 'index.html', SETTINGS.build + 'templates/*.html', SETTINGS.build.css + '*css', SETTINGS.build.js + '*.js'], {
        proxy: {
            host: '127.0.0.1',
            port: serverConfig.port
        }
    });
});

/*============================================================
 =                       Automated Test                      =
 ============================================================*/
gulp.task('test', ['test:init', 'test:run']);
gulp.task('tdd', ['test:init', 'test:server']);

gulp.task('test:init', function () {
    console.log(hintLog('-------------------------------------------------- TEST - Setup'));
    // Nothing to do, yet...
});

gulp.task('test:run', function (done) {
    console.log(hintLog('-------------------------------------------------- TEST - Execute'));
    return new KarmaServer({
        configFile: __dirname + '/karma.conf.js',
        singleRun: true
    }, done).start();
});
gulp.task('test:server', function (done) {
    console.log(hintLog('-------------------------------------------------- TEST - Server'));
    return new KarmaServer({
        configFile: __dirname + '/karma.conf.js',
    }, done).start();
});
